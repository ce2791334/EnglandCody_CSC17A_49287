/*
 * File: main.cpp
 * Author: Cody England
 * Created on August 29, 2020, 3:18 AM
 * Purpose: Convert Currency
 * Version: 1.0
 */

//System libraries
#include <iostream>
#include <iomanip>

//User Libraries - Post Here 

//Declare global constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
const float YEN_PER_DOLLAR = 105.36;
const float EUROS_PER_DOLLAR = 0.84;

//Function Prototypes - Post Here

//Execution Begins Here
using namespace std;

//Main fxn
int main(int argc, char** argv) {

    //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    unsigned char choice; //Variable for determining money type conversion
    float amnt;  //Variable holding amount to convert
    
    //Display initial conditions, headings here 
    
    //Ask user for type of conversion
    cout << "Enter 1 to convert dollars to yen";
    cout << "\nor 2 to convert dollars to euros: ";
    cin >> choice;
    
    //Ask user for value to convert
    cout << "\nEnter the dollar amount you wish to convert: ";
    cin >> amnt;
    cout << endl;
    
    //Convert value based on type of conversion
    if ( choice == 1 )
    {
        //Convert to yen
        float yen = amnt * YEN_PER_DOLLAR;
       
        //Display results
        cout << fixed << setprecision(2);
        cout << "$" << amnt << " = ";
        cout << "¥" << yen;
    }
    else 
    {
        //Convert to euros
        float euros = amnt * EUROS_PER_DOLLAR;
        
        //Display results
        cout << fixed << setprecision(2);
        cout << "$" << amnt << " = ";
        cout << "€" << euros;
    }
    //Clean up allocated memory here
    
    //Exit program
    return 0;
}

