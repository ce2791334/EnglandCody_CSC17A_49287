/*
 * File: main.cpp
 * Author: Cody England
 * Created on August 29, 2020, 11:18 AM
 * Purpose: Convert Celsius to Fahrenheit
 * Version: 1.0
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables

//Function prototypes - post here
int popcalc(int Pv, float i, int n);

//Execution Begins Here
int main(int argc, char** argv) {

   //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    unsigned short int StartPop,  //Positive values that should not exceed 
                       numdays;   //a few thousand 
    float ave_inc;      //Positive value that should not exceed 100
 
    
    //Display initial conditions, headings here - none
    
    do { //Loop for data validation
    //ask user for data
    cout << "Enter the starting population,\n"
           << "the average daily population increase (as a percentage),"
           << "\nand the number of days over which the population grows:"
           << "\n";
    cin >> StartPop >> ave_inc >> numdays;
    
    //Data validation of user input
    string msg = ((StartPop < 2 || StartPop % 1 != 0) ? 
                   "ERROR: Starting population must be a whole " 
                   "number that's not less than 2" :
                   (ave_inc < 0) ? 
                    "ERROR: Daily population increase must be "
                    "greater than 0" : 
                   (numdays < 1) ?
                    "ERROR: Number of days must be greater than "
                    "1" :
                    "Processing!\n");
    
    //Output ERROR message or "Processing!"
    cout << endl << msg << endl;
    
      //Run loop while as long as user inputs invalid data
    } while(StartPop < 2 || StartPop%1 != 0 || ave_inc < 0 || numdays < 1);
    
    //Call the calculation function
    popcalc(StartPop, ave_inc, numdays);
    
    //Exit program
    return 0;
}

  
popcalc(int Pv, float i, int n)
{
    //Declare fxn variables
    float Fv = Pv;
    
    //Change population daily increase percentage
    //to a decimal
    i /= 100;
    
    //Output starting population
    cout << "The starting population is: " << Fv << endl;
   
    //For loop that calculates and displays the population after 
    //each day up to the day entered
    for(int j = 1; j <= n; j++) 
    {
     Fv *= (1 + i); 
   
     cout << "The population after day " << j
          << " is: " << fixed << setprecision(2)
          << Fv << endl;
      
    }
    
    //Exit fxn
    return 0;
}