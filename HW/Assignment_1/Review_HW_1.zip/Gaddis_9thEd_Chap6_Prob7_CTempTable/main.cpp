/*
 * File: main.cpp
 * Author: Cody England
 * Created on September 6, 2020, 7:49 PM
 * Purpose: Convert Fahrenheit to Celsius
 * Version: 1.0
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables

//Function prototypes - post here
int Celsius(int F_temp);

//Execution Begins Here
int main(int argc, char** argv) {

   //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less

    //Display initial conditions, headings here 
    cout << "NOTE: This program rounds down to the nearest whole "
         << "number \n\n";
    
    //Display headings of temperature conversion table
    cout << "Temperature: \n";
    cout << setw(10) << "Fahrenheit" << setw(11) 
         << "Celsius \n";
    
    //Call the conversion function
    //Loop to display conversions from 0 to 20 degrees Fahrenheit
    for (int i = 0; i <= 20; i++)
    {
        Celsius(i);
    }
    
    //Exit program
    return 0;
}

//Celsius fxn
Celsius(int F_temp)
{
    //Convert Fahrenheit to Celsius
    //Output results
    cout << setw(5) << F_temp << setw(12)
         << (F_temp - 32) * 5 / 9 << endl;
}