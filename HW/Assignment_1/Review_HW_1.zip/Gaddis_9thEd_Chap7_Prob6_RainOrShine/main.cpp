/*
 * File: main.cpp
 * Author: Cody England
 * Created on September 6 , 2020, 8:41 PM
 * Purpose: Convert Celsius to Fahrenheit
 * Version: 1.0
 */


//System libraries
#include <iostream>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables

//Function prototypes - post here
void countDays(char wthr[][30], char row, char col);

//Execution Begins Here
int main(int argc, char** argv) {

   //Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare variables or constants here
    //7 characters or less
    const char MONTH = 3;   //Row constant
    const char DAY = 30;     //Column constant
    char wthr[MONTH][DAY];    //Array
    char letter;              //Assigned to 'R', 'C', or 'S'
    char var;                //Will hold the random number 
                             //from seed between 0 and 3
    ifstream ipFile;        //Input file variable
    ofstream opFile;      //Output file variable
    
    //Display initial conditions, headings here 
    //Create RainOrShine.txt with random data to be read later
   opFile.open("RainOrShine.txt");
    
   //Output statement lets us know file's open
   cout << "Now writing data to file..." << endl;  
   
   //For loop to write data in a 3x30 tabular form
    for (int cntCol = 0; cntCol < MONTH; cntCol++)
    {
        for (int cntRow = 0; cntRow < DAY; cntRow++)
        {
        //Assign random value between 0 and 3
        var = rand()%3;
        
        //Convert 0-3 to 'R', 'C', or 'S'
        letter = ((var == 0) ? 'R' :
               (var == 1) ? 'C' : 
                'S');
        //Write values to file
        opFile << letter << " ";
        }
        opFile << "\n";
    }
   //Close file
    opFile.close();
    //Lets us know file is closed
    cout <<"Output file closed\n";
    
    //Open file to read
    ipFile.open("RainOrShine.txt");
  
    //Loop to read in data from file to array
    for (int cntRow = 0; cntRow < MONTH; cntRow++)
    {
        for (int cntCol = 0; cntCol < DAY; cntCol++)
        {
            ipFile >> wthr[cntRow][cntCol];
        }
     
    }
    //Close file
    ipFile.close();
   
   //Lets us know file is closed
    cout <<"Input file closed\n";
    
    //Call counting function
    countDays(wthr, MONTH, DAY);
    
    
    //Exit program
    return 0;
}

//Begin function for counting rainy, cloudy, and sunny days
  void countDays(char wthr[][30], char row, char col)
    {
        //Declare fxn variables
        char letter;
        char numR = 1;
        char numS = 1;
        char numC = 1;
        char Rain1,
             Rain2,
             Rain3;
        //Loop that counts rainy, sunny, and cloudy
        //days each month
        for (int cntRow = 0; cntRow < row; cntRow++)
        {
         for (int cntCol = 0; cntCol < col; cntCol++)
          {
            //Keeps track of number of rainy, sunny, and cloudy
            //days
            letter = wthr[cntRow][cntCol];
            
            if (letter == 'R') 
                numR++;
            if (letter == 'C')
                numC++;
            if (letter == 'S')
                numS++;
            
          }
        //Conditional output of results for June, July, and August
        //June
        if (cntRow == 0)
        {
            cout << "The number of rainy days in June "
                 << "were: " << numR - 1 << endl;
            cout << "The number of cloudy days in June "
                 << "were: " << numC - 1<< endl;
            cout << "The number of sunny days in June "
                 << "were: " << numS - 1<< "\n\n";
            
           Rain1 = numR;
        }
        //July
        if (cntRow == 1)
        {
            cout << "The number of rainy days in July "
                 << "were: " << numR -1 << endl;
            cout << "The number of cloudy days in July "
                 << "were: " << numC - 1<< endl;
            cout << "The number of sunny days in July "
                 << "were: " << numS - 1<< "\n\n";
            
            Rain2 = numR;
        }
        //August
        if (cntRow == 2)
        {
            cout << "The number of rainy days in August "
                 << "were: " << numR - 1<< endl;
            cout << "The number of cloudy days in August "
                 << "were: " << numC - 1<< endl;
            cout << "The number of sunny days in August "
                 << "were: " << numS - 1<< "\n\n";
            
            Rain3 = numR;
        }
         //Reset numR variable for each loop iteration
         numR -= numR - 1;
         numC -= numC - 1;
         numS -= numS - 1;
        
        }
        //Compare months
        string most = ((Rain1 > Rain2 && Rain1 > Rain3) ? 
                        "June had the most rainy days" :
                    (Rain1 > Rain2 && Rain1 > Rain3) ? 
                        "July had the most rainy days" :
                        "August had the most rainy days");
        //Output month with most rain
        cout << most;
        
        //Function Complete
    }