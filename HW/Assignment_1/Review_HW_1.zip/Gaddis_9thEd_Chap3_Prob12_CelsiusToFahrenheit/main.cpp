/*
 * File: main.cpp
 * Author: Cody England
 * Created on August 29, 2020, 11:18 AM
 * Purpose: Convert Celsius to Fahrenheit
 * Version: 1.0
 */

//System libraries
#include <iostream>

using namespace std;
//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {

    //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    int temp;  //input temp from user
    unsigned char convert; // variable for option choice
    
    //Display initial conditions, headings here - none
    
    //Ask user for type of conversion
    cout << "Enter 1 to convert Fahrenheit to ";
    cout << "Celsius \nor 2 to convert Celsius to Fahrenheit: ";
    cin >> convert;
    
    //Ask user for value to convert
    cout << "\nEnter the temperature you wish to convert: ";
    cin >> temp;
    
    //Convert value based on type of conversion
    if ( convert == 1 )
    {
        int degC = (temp - 32) * 5/9; //Convert Fahrenheit temp to Celsius
       
        //Display conversion
        cout << temp << " degrees Fahrenheit = ";
        cout << degC << " degrees Celsius.";
    }
    else 
    {
        int degF = 9/5*temp + 32;     //Convert Celsius temp to Fahrenheit
        
        //Display conversion
        cout << temp << " degrees Celsius = ";
        cout << degF << " degrees Fahrenheit.";
    }
    //Clean up allocated memory here
    
    //Exit program
    return 0;
}

