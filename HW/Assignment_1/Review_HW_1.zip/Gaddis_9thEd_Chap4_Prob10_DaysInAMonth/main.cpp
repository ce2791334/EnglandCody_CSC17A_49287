/*
 * File: main.cpp
 * Author: Cody England
 * Created on September 1, 2020, 9:30 AM
 * Purpose: Determine the days in a month 
 * Version: 1.0
 */

//System libraries
#include <iostream>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {

    //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    unsigned short int yr,  //variable for user chosen year
                       month, //variable for user chosen month
                       numdays;   /*variable for calculating number of days in 
                                    the month*/
    
    //Display initial conditions, headings here - none
    
    do {
    //Ask user for month and year
    cout << "Enter the month number (1-12) and the year: " << endl;
    cin >> month >> yr;
               
    //A little input validation
        if( month < 0 || month > 12 )
            cout << "ERROR: must enter a value between 1 and 12!" 
                    << endl;
    cout << month << "  " << yr << "\n\n";
                    
        } while (month < 0 || month > 12);
        
    //Check for leap year: yes == 1, no == 0
    char lpyr = ((yr % 100 == 0 && yr % 400 == 0) ? 1 :
            (yr % 4 == 0) ? 1 :
            0);
    
    //Days in February during leap year
    if ( lpyr == 1 && month == 2)
    {
        //Special case of February length under these conditions
        cout << yr << " is a leap year!\n";
        cout << "There are 29 days in month " << month << endl;
    }
    //Days in rest of months 
    else 
    {
                //Odd months before August have 31 days 
        numdays = ((month < 8 && month % 2 == 1 && month != 2) ? 31:
                //Even months before August have 30 days besides Feb.
                   (month >= 8 && month % 2 == 0) ? 31:
                //Even months after August have 30 days 
                   (month < 8 && month % 2 == 0 && month != 2) ? 30:
                //Odd months after August have 30 days 
                   (month >= 8 && month % 2 == 1) ? 30:
                    28);
                //Display days in given month during given year
                cout << "There are " << numdays << " days in month ";
                cout << month << endl;
    }
    //Clean up allocated memory here
    
    //Exit program
    return 0;
}



