/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on September 7, 2020, 10:38 PM
 * Purpose:  Binary String Search
 * Version: 1.0
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>

using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
void BubbleSort(string names[], char size);
int BinarySearch(string names[], char size, string name);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const int NUM_NAMES = 20;
    int results;
    string name;
    string names[NUM_NAMES] = {"Collins, Bill", "Smith, Bart", 
                               "Allen, Jim", "Griffin, Jim", 
                               "Stamey, Marty", "Rose, Geri",
                               "Taylor, Terri", "Johnson, Jill", 
                               "Allison, Jeff", "Looney, Joe", 
                               "Wolfe, Bill", "James, Jean",
                               "Weaver, Jim", "Pore, Bob",
                               "Rutherford, Greg", "Javens, Renee",
                               "Pike, Gordon", "Holland, Beth" };
    
    //Call the sort function for array
    BubbleSort(names, NUM_NAMES);
    
    for (int i = 0; i < NUM_NAMES; i++)
        cout << names[i] << endl;
    
    //Ask user for name to search for
    cout << "Enter the name you wish to search for: " << endl;
    getline(cin, name, '\n');
    
    //Call the binary search function
    results = BinarySearch(names, NUM_NAMES, name);
 
    //Output failure if result not found
    string output = ((results == -1) ? 
             " wasn't found " :
             " was found at element ");
    
    //Output results
    cout << name << output << results;
  
    //Exit program!
    return 0;
}

//Begin BinarySearch function
int BinarySearch(string names[], char size, string name)
{
    //Declare function variables
int first = 0, 
    last = size-1;

    //Loop until value is found or whole array is searched
    while( first <= last)
    {
        int mid = (first+last)/2;  //Start search at midpoint
        
        if (names[mid]== name)
        return mid; //Return index if found
        
        if (names[mid] > name)
        last = mid - 1;
        
        if (names[mid] < name) 
        first = mid + 1;
        
    }
    // if we went through all values and didn't find
    //our search value, return -1
    return -1; 
}

//Begin BubbleSort function
void BubbleSort(string names[], char size)
{
    //Declare function variables
    int maxVal;
    int i;
    
    //Loop until all elements are in ascending order
    for (maxVal = size -1; maxVal > 0; maxVal--)
    {
        for (i = 0; i < maxVal; i++)
        {
            if (names[i] > names[i + 1])
                swap(names[i], names[i + 1]);
        }
    }
    //End function
}