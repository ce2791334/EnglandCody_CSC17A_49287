/* 
 * File: main.cpp
 * Author: Cody England
 * Created on Oct. 6, 2020
 * Purpose: Use structures to store company data
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structures
struct Div
{
    //4 company divisions
    float East;
    float West;
    float North;
    float South;
};

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    Div frstQrt;
    Div scndQrt;
    Div thrdQrt;
    Div frthQrt;
    float Qrtrs = 4;
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    cout << "North\n";
    cout << "Enter first-quarter sales:\n";
    cin >> frstQrt.North;
    cout << "Enter second-quarter sales:\n";
    cin >> scndQrt.North;
    cout << "Enter third-quarter sales:\n";
    cin >> thrdQrt.North;
    cout << "Enter fourth-quarter sales:\n";
    cin >> frthQrt.North;
    
    cout << fixed << setprecision(2);
    //Calculate total annual sales for the division
    float totAnlN = (frstQrt.North + scndQrt.North + thrdQrt.North + frthQrt.North);
    cout << "Total Annual sales:$" << totAnlN << endl;
    
    //Calculate average quarterly sales for the division
    float aveQrtN = totAnlN / Qrtrs;
    cout << "Average Quarterly Sales:$" << aveQrtN/1.00 << endl;
    
    //Process or map Inputs to Outputs
    cout << "West\n";
    cout << "Enter first-quarter sales:\n";
    cin >> frstQrt.West;
    cout << "Enter second-quarter sales:\n";
    cin >> scndQrt.West;
    cout << "Enter third-quarter sales:\n";
    cin >> thrdQrt.West;
    cout << "Enter fourth-quarter sales:\n";
    cin >> frthQrt.West;
    
    //Calculate total annual sales for the division
    float totAnlW = frstQrt.West + scndQrt.West + thrdQrt.West + frthQrt.West;
    cout << "Total Annual sales:$" << totAnlW << endl;
    
    //Calculate average quarterly sales for the division
    float aveQrtW = totAnlW / Qrtrs;
    cout << "Average Quarterly Sales:$" << aveQrtW << endl;
    
    //Process or map Inputs to Outputs
    cout << "East\n";
    cout << "Enter first-quarter sales:\n";
    cin >> frstQrt.East;
    cout << "Enter second-quarter sales:\n";
    cin >> scndQrt.East;
    cout << "Enter third-quarter sales:\n";
    cin >> thrdQrt.East;
    cout << "Enter fourth-quarter sales:\n";
    cin >> frthQrt.East;
    
    //Calculate total annual sales for the division
    float totAnlE = frstQrt.East + scndQrt.East + thrdQrt.East + frthQrt.East;
    cout << "Total Annual sales:$" << totAnlE << endl;
    
    //Calculate average quarterly sales for the division
    float aveQrtE = totAnlE / Qrtrs;
    cout << "Average Quarterly Sales:$" << aveQrtE << endl;
    
    //Process or map Inputs to Outputs
    cout << "South\n";
    cout << "Enter first-quarter sales:\n";
    cin >> frstQrt.South;
    cout << "Enter second-quarter sales:\n";
    cin >> scndQrt.South;
    cout << "Enter third-quarter sales:\n";
    cin >> thrdQrt.South;
    cout << "Enter fourth-quarter sales:\n";
    cin >> frthQrt.South;
    
    //Calculate total annual sales for the division
    float totAnlS = frstQrt.South + scndQrt.South + thrdQrt.South + frthQrt.South;
    cout << "Total Annual sales:$" << totAnlS << endl;
    
    //Calculate average quarterly sales for the division
    float aveQrtS = totAnlS / Qrtrs;
    cout << "Average Quarterly Sales:$" << aveQrtS;
    
    //Display Outputs

    //Exit stage right!
    return 0;
}
