/* 
 * File: main.cpp
 * Author: Cody England
 * Created on October 11 2020 @ 9:14pm
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions
//Sturctures 
struct Drink{
    
    string name;
    float cost;
    int nDrnks;
};

struct Type{
    
    Drink *drink;
};


//Function Prototypes
Type *initial(char);
Type display(Type *,char);
int Choice(Type *,char);
void destroy(Type *);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    char nType = 5;
    Type *stockd;
    
    //Initialize Variables
    stockd = initial(nType);
    
    //Display options
    display(stockd, nType);
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Delete allocated memory
    destroy(stockd);
    //Exit stage right!
    return 0;
}


//Initialize structure values
Type *initial(char n)
{
    Type *toStart = new Type;
    toStart->drink = new Drink[n];
    
    toStart->drink[0].name = "Cola";
    toStart->drink[0].cost = 75;
    toStart->drink[0].nDrnks = 20;
    
    toStart->drink[1].name = "Root";
    toStart->drink[1].cost = 75;
    toStart->drink[1].nDrnks = 20;
    
    toStart->drink[2].name = "Lemon-Lime";
    toStart->drink[2].cost = 75;
    toStart->drink[2].nDrnks = 20;
    
    toStart->drink[3].name = "Grape";
    toStart->drink[3].cost = 80;
    toStart->drink[3].nDrnks = 20;
    
    toStart->drink[4].name = "Cream";
    toStart->drink[4].cost = 80;
    toStart->drink[4].nDrnks = 20;

return toStart;
}


//Display fxn
Type display(Type *menu, char n)
{
    
    for(int i = 0; i < n; i++)
    {
        cout << left << setw(10);
        cout << menu->drink[i].name << " " << menu->drink[i].cost 
         << "  " << menu->drink[i].nDrnks << endl;
    }
    cout << "Quit\n";
    
    //Call fxn to handle user's choice
    Choice(menu, n);
}


//Fxn for users choice of drink
int Choice(Type *menu, char n)
{
    string choice;
    int amtPd;
    int ernd = 0;
 
    
    cin >> choice >> amtPd;
    int cnt = 0;
    for(int i = 0; i < n; i++)
    {
        if(choice == menu->drink[i].name)
        {
            cout << amtPd - menu->drink[i].cost << endl;
            menu->drink[i].nDrnks -= 1;
            ernd += menu->drink[i].cost;
            cnt++;
        }
    }
    if(!cnt)
    {
        cout << ernd << endl;
        return 0;
    }
    //Offer menu again if user didn't quit
     display(menu, n);
}

void destroy(Type *sDrnks){
    //Clean Up the Dynamic Stuff
   
    delete [] sDrnks->drink;//Now the array of Structures
    delete sDrnks;//Now deallocate the final Movie Structure
}
