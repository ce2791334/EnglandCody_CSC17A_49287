/* 
 * File: main.cpp
 * Author: Cody England
 * Created on October 11 2020 @ 7:50pm
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions
//Sturctures 
struct MBudget{
    float Hsing;
    float Utils;
    float hExpnse;
    float Trnsprt;
    float Food;
    float Med;
    float Ins;
    float Entrtn;
    float Clthng;
    float Misc;
    float Total;
};


//Function Prototypes
MBudget budget();
MBudget read();
MBudget analyze(MBudget,MBudget);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    MBudget Budget;
    MBudget spent;
    //Initialize Variables
    
    //Set Budget
    Budget = budget();
    //What you spent this month
    spent = read();
    
    //Check amounts spent against budget
    analyze(spent, Budget);
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}

//Fxn to hold budget values
MBudget budget()
{
    MBudget Bud;
    Bud.Hsing = 500;
    Bud.Utils = 150;
    Bud.hExpnse = 65;
    Bud.Trnsprt = 50;
    Bud.Food = 250;
    Bud.Med = 30;
    Bud.Ins = 100;
    Bud.Entrtn = 150;
    Bud.Clthng = 75;
    Bud.Misc = 50;
    Bud.Total = Bud.Hsing + Bud.Utils + Bud.hExpnse +
            Bud.Trnsprt + Bud.Food + Bud.Med +
            Bud.Ins + Bud.Entrtn + Bud.Clthng + Bud.Misc;
    
    return Bud;
}

//Fxn to read in values
MBudget read()
{
    MBudget sp;
    
    cout << "Enter housing cost for the month:$\n"
         << "Enter utilities cost for the month:$\n"
         << "Enter household expenses cost for the month:$\n"
         << "Enter transportation cost for the month:$\n"
         << "Enter food cost for the month:$\n"
         << "Enter medical cost for the month:$\n"
         << "Enter insurance cost for the month:$\n"
         << "Enter entertainment cost for the month:$\n"
         << "Enter clothing cost for the month:$\n"
         << "Enter miscellaneous cost for the month:$\n";
         
    cin >> sp.Hsing >> sp.Utils >> sp.hExpnse >> sp.Trnsprt >> sp.Food 
        >> sp.Med >> sp.Ins >> sp.Entrtn >> sp.Clthng >> sp.Misc;
        
    sp.Total = sp.Hsing + sp.Utils + sp.hExpnse +
            sp.Trnsprt + sp.Food + sp.Med +
            sp.Ins + sp.Entrtn + sp.Clthng + sp.Misc;
        return sp;
}


MBudget analyze(MBudget spent, MBudget bdgt)
{
    //Declare fxn variables
    string stat;
    float result;
    
    //Compare each expenditure to budgeted amount
    stat = ((spent.Hsing > bdgt.Hsing) ? "Housing Over" :
            (spent.Hsing < bdgt.Hsing) ? "Housing Under" :
            "Housing Even");
    cout << stat << endl;
    
    stat = ((spent.Utils > bdgt.Utils) ? "Utilities Over" :
            (spent.Utils < bdgt.Utils) ? "Utilities Under" :
            "Utilities Even");
    cout << stat << endl;
    
    stat = ((spent.hExpnse > bdgt.hExpnse) ? "Household Expenses Over" :
            (spent.hExpnse < bdgt.hExpnse) ? "Household Expenses Under" :
            "Household Expenses Even");
    cout << stat << endl;
    
    stat = ((spent.Trnsprt > bdgt.Trnsprt) ? "Transportation Over" :
            (spent.Trnsprt < bdgt.Trnsprt) ? "Transportation Under" :
            "Transportation Even");
    cout << stat << endl;
    
    stat = ((spent.Food > bdgt.Food) ? "Food Over" :
            (spent.Food < bdgt.Food) ? "Food Under" :
            "Food Even");
    cout << stat << endl;
    
    stat = ((spent.Med > bdgt.Med) ? "Medical Over" :
            (spent.Med < bdgt.Med) ? "Medical Under" :
            "Medical Even");
    cout << stat << endl;
    
    stat = ((spent.Ins > bdgt.Ins) ? "Insurance Over" :
            (spent.Ins < bdgt.Ins) ? "Insurance Under" :
            "Insurance Even");
    cout << stat << endl;
    
   stat = ((spent.Entrtn > bdgt.Entrtn) ? "Entertainment Over" :
            (spent.Entrtn < bdgt.Entrtn) ? "Entertainment Under" :
            "Entertainment Even");
    cout << stat << endl;
    
   stat = ((spent.Clthng > bdgt.Clthng) ? "Clothing Over" :
            (spent.Clthng < bdgt.Clthng) ? "Clothing Under" :
            "Clothing Even");
    cout << stat << endl;
    
   stat = ((spent.Misc > bdgt.Misc) ? "Miscellaneous Over" :
            (spent.Misc < bdgt.Misc) ? "Miscellaneous Under" :
            "Miscellaneous Even");
    cout << stat << endl;
   
   //Compute difference in expenditures vs. budgeted amounts
   result = spent.Total - bdgt.Total;
   
   //Format results
   cout << fixed << setprecision(2);
   //Display results of the month
if(result < 0)
cout << "You were $" << result * -1 << " under budget";

else 
cout << "You were $" << result << " over budget";
}









