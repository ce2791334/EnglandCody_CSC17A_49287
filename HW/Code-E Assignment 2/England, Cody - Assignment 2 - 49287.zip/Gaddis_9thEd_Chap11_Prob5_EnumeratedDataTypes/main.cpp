/* 
 * File: main.cpp
 * Author: Cody England
 * Created on October 8, 2020
 * Purpose: Convert a weather statistics program to use enumerated data types
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structures
struct WStats{
  
  float tRainfl;
  int hTemp;
  int lTemp;
  float avTemp;
};

//Function Prototypes
void print();

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    const int SIZE = 36;
    WStats month;
    WStats ave;
    float ary[SIZE];
    float totRain = 0;
    int high = -100;        //initialize to lowest possible temp
    int low = 140;          //initialize to highest possible temp
    int totTemp;
    float mthAve;             //Average per month
    float aveTot = 0;             //Running total of the monthly averages
    
    enum Month{JAN, FEB, MAR, APR, MAY, JUNE, JULY,
               AUG, SEP, OCT, NOV, DEC};
    
    //WStats Jan, Feb, Mar, Apr, May, Jun;
   //Initialize Variables
   //read(size, nmths);
    int i = 0;
    //Process or map Inputs to Outputs
    
    //Loop to retrieve all inputs
    while(cin >> month.tRainfl >> month.hTemp >> month.lTemp){
    //Keep track of the total rainfall
    totRain += month.tRainfl;
    
    //Data validation
    if (month.hTemp <= 140 && month.hTemp >= -100
        && month.lTemp <=140 && month.lTemp >= -100)
        {
    ary[i] = month.tRainfl;
    i++;
    ary[i] = month.hTemp;
    i++;
    ary[i] = month.lTemp;
    i++;
    
    print();
        }
        else 
        {   cout << "Error: Temperature values not in range";
            return 0;
        }
    } 
    
    //Calculate and display the average monthly rainfall
    int nMths = i / 3;
    cout << "Average monthly rainfall:" << totRain / nMths << endl;
    
    //Check array for highest temp
    for(int j = JAN; j <= i/MAR; j++)
        high = ((ary[ j * APR + FEB ] > high) ? ary[j * APR + FEB] : high);
        cout << "High Temp:" << high << endl;
        
    //Check array for lowest temp
    for(int j = JAN; j <= i/APR - FEB; j++)
        low = ((ary[j * APR + MAR] < low) ? ary[j * APR + MAR] : low);
        cout << "Low Temp:" << low << endl;
    
    //Calculate average Temp
    for(int j = 0; j <= i; j++)
    {
        if(j % 3 != 0)
        totTemp += ary[j];
        
        else 
        {
            if(totTemp != 0)
            { 
             mthAve = totTemp / 2.0;
             aveTot += mthAve;
             totTemp = 0;
            }
        }
    }
    
    //Calculate and display the average temperature
    ave.avTemp = aveTot / nMths;
    cout << fixed << setprecision(1) 
         << "Average Temp:" << ave.avTemp;
    
    //Display Outputs
     
    //Delete allocated memory
  
    //Exit stage right!
    return 0;
}


void print()
{
    cout << "Enter the total rainfall for the month:\n"
         << "Enter the high temp:\n"
         << "Enter the low temp:\n";
}

