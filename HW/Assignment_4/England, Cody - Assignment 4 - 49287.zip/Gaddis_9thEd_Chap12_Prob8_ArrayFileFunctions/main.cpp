/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 15, 2020, 8:11 AM
 * Purpose: Write an array to a binary file then write 
 * the binary file to an array
 */

//System libraries
#include <fstream>
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions
//Sturctures 

//Function prototypes
void arrayToFile(fstream &,int *,int); //Function names longer than
void fileToArray(fstream &,int *,int); //7 characters but problem
                                       //said to use these names                                 
void display(int *,int);
//Execution begins here
int main(int argc, char** argv) {
    //Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
    //Declare variables
    string flNm;
    const int SIZE = 10;
    int *toBAry,
        *frmBAry;
    fstream BinFile;
    //Allocate memory in dynamic arrays
    toBAry = new int [SIZE];
    frmBAry = new int [SIZE];
    //Call the write fxn
    arrayToFile(BinFile, toBAry, SIZE);
   //Call read fxn
    fileToArray(BinFile, frmBAry, SIZE);
    //Call display fxn
    display(frmBAry, SIZE);
    //Delete memory
    delete []toBAry;
    delete []frmBAry;
    return 0;
}

//Begin fxn to write array to file
void arrayToFile(fstream &file, int *ary, int size)
{
    //Open file
    file.open("Binary.txt", ios::out | ios::binary);
    //Check if file exists
    if(file)
    { 
    //Create array of random integers and write
    //it to the binary file
        for(int i = 0; i < size; i++)
        ary[i] = rand() % 100;
        //Write the array to the file
        file.write(reinterpret_cast<char *>(ary),size*sizeof(int));    
    }
    else
        cout << "Couldn't open file...\n";
    //Close file
    file.close();
}

//Begin fxn to write file to array
void fileToArray(fstream &file, int *ary, int size)
{
    //Open file
    file.open("Binary.txt", ios::in | ios::binary);
    //Check if file exists
    if(file)
    { 
        //Read the binary file into an array
        file.read(reinterpret_cast<char *>(ary), size*sizeof(int)); 
    }
    else
        cout << "Couldn't open file...\n";
    //Close file
    file.close();
}

//Begin display fxn
void display(int *ary, int size)
{
    //Display the array read in from the binary file
    for(int i = 0; i < size; i++)
        cout << ary[i] << " ";
        cout << endl; 
}
