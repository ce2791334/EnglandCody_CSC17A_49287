/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 15, 2020, 8:11 AM
 * Purpose: Write structure data to a file
 * Version 2
 */

//System libraries
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;
//User Libraries
#include "Div.h"
//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
void fillDat(fstream &,const int);
int ask(fstream &,Div *,int);
void totAn(Div *,int, float);
float aveQrt(float,int);
void wrtBin(fstream &,Div *,int);
void display(float,float);
void destroy(Div *divs);
void readBin(fstream &in,Div *a,int);
void readTxt(fstream &in,Div *a,int);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    float Qrtrs = 4;
    fstream binFile;
    //Open binary file
    binFile.open("data.bin",ios::in|ios::out|ios::binary);
    //Initialize Variables
     fillDat(binFile, Qrtrs);
    //Destroy allocated memory
//    destroy(Corp);
    //Close file
    binFile.close();
    //Exit stage right!
    return 0;
}

//Begin the fill structure data fxn
void fillDat(fstream &binFile, const int qrts)
{
    //Declare fxn variables
    float totAnl;
    //Loop to assign the quarter to each division and then ask user
    //for sales in each quarter
    for(int i = 0; i < qrts; i++){
        Div *divs = new Div;
        divs->qtr = i + 1;
        divs->Name = ((i % 4 == 0) ? "North" : (i % 4 == 1) 
                       ? "West" : (i % 4 == 2) ? "East" :
                       "South" );
        cout << divs->Name << endl;
        //Ask user for inputs
        float tot = ask(binFile, divs, qrts);
        cout << endl << endl << tot << endl << endl;
        //Calculate the total annual sales in each division
        totAn(divs, qrts, tot);
        delete divs;
    }
   
}

//Begin fxn to ask user for input
int ask(fstream &binFile, Div *div, int qrt)
{
    float tot = 0;
    //Ask user for input
    cout << "Enter first-quarter sales:\n"
         << "Enter second-quarter sales:\n"
         << "Enter third-quarter sales:\n"
         << "Enter fourth-quarter sales:\n"; 
    //retrieve input
    for(int i = 0; i < qrt; i++)
    {
     cin >> div->sales;
     tot += div->sales;
     if(div->sales < 0)
         do{
            cout << "Error: must input positive "
                 << "numbers for sales..." << endl;
            cin >> div->sales;
         } while(div->sales < 0); 
        //Write data to binary file
        wrtBin(binFile, div, qrt);
    }
    return tot;
}

//Begin fxn to calculate the total annual sales
//for the division
void totAn(Div *div, int qrt, float tot)
{
    //Declare fxn variables
    float total = tot;
        //Calculate average quarterly sales
        ave = aveQrt(total, qrt);
        //Display results for the division
        display(total, ave);
}

//Begin fxn to calculate the average quarterly sales 
//for the division
float aveQrt(float total, int qrt)
{
    //Calculate the average quarterly sales for the division
    float ave = total/qrt;
    return ave;
}

//Begin fxn to display total sales and average quarterly sales
void display(float total,float aveQrt)
{
        //Format output and display total
        cout << fixed << setprecision(2);
        cout << "Total Annual sales:$" << total << endl;
        cout << "Average Quarterly Sales:$" << aveQrt/1.00 << endl;
}

//Begin fxn to write to binary file
void wrtBin(fstream &out,Div *a,int n){
    fstream tFile;
    tFile.open("file.txt", ios::in|ios::out);
    for(int i = 0; i < n; i++)
    {
    out.write(reinterpret_cast<char *>(&a->sales),sizeof(a->sales));
    tFile << a->sales;
    }
}

void readBin(fstream &in,Div *a,int n){
    //Declare and initialize variables
    
    in.read(reinterpret_cast<char *>(a),sizeof(a));
   
}
void readTxt(fstream &in,Div *a,int n){
    //Declare and initialize variables
    char ch;
    in.clear();
    in.seekp(0, ios::beg);
    in.get(ch);
    while(in.get(ch)){
        cout << ch << " ";
    }
   
}
//Begin fxn to destroy allocated memory
void destroy(Div *divs){
    //Clean Up the Dynamic Stuff
   // delete [] divs->Name;//Now the array of Structures
   // delete divs;//Now deallocate the final division Structure
  
}

///////////Ask about binary and dump file 