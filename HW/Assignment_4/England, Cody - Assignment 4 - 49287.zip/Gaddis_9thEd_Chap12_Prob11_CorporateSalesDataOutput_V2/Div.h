
/* 
 * File:   Div.h
 * Author: Cody Enlgland
 *
 * Created on October 15, 2020, 6:48 PM
 */

#ifndef DIV_H
#define DIV_H

//#include "Qtr.h"
struct Div{
    //4 company divisions
    string Name;
    //Each name represents eitherNorth, West, 
    //East, or South
    int qtr;
    float sales;
};

#endif /*DIV_H*/