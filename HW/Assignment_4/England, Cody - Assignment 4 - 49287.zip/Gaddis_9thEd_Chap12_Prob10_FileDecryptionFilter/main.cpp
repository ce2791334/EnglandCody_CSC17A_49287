/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 18, 2020, 8:15 PM
 * Purpose Decrypt a file
 */

//System libraries
#include <fstream>
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions
//Sturctures 

//Function prototypes
char *readFl(fstream &,int &);               //Read in the file
void decrypt(fstream &,char *, const int) ;  //Encrypt the file                           
void display(char *,const int);              //Display the encrypted file

//Execution begins here
int main(int argc, char** argv) {
    //Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
    //Declare variables
    int size = 0;
    fstream inFile,
            outFile;
    //Open files
    inFile.open("Encrypted.txt", ios::in);
    outFile.open("Decrypted.txt", ios::out);
    //Write the file to an array
    char *array = readFl(inFile, size);
    //Encrypt the array
    decrypt(outFile, array, size);  

    //Delete memory
    delete []array;
    return 0;
}

//Begin fxn to write file to array
char *readFl(fstream &file, int &size)
{
    //Declare fxn variables
    string line;
    char *ary;
    //Check if file exists
    if(file)
    { 
        //Get size of file
        file.seekg(0L, ios::end);
        int nBytes = file.tellg();
        //Reset cursor to beginning of file
        file.seekp(0L,ios::beg);
        //Create a dynamic array
        ary = new char[nBytes];
        
        cout << "Here is your encrypted file:" << endl;
        //Read in the file
        getline(file, line);
        //Loop to find the size of the file
        while(file)
        {
            //For loop to write each word to the array
            for(int i = 0; i < line.size(); i++)
            {
             ary[size] = line[i];
             //Display original file
             cout << ary[i];
             //Keep track of array size
             size++;
             
            }   
         getline(file, line);
        }
    }
    else
        cout << "Couldn't open file...\n";
    cout << endl;
    //Close file
    file.close();
    return ary;
}

//Begin fxn to encrypt the file
void decrypt(fstream &file, char *ary, const int sz)
{
    //For loop to chage the values in the array
    for(int i = 0; i < sz; i++)
    {
        ary[i] -= 10;
        //Write encrypted array to a new file
        file.put(ary[i]);
    }
    display(ary, sz);
}

//Display encrypted file
void display(char *a, const int sz)
{
    cout << "Here is your decrypted file:" << endl;
     for(int i = 0; i < sz; i++)
           cout << a[i];
}
