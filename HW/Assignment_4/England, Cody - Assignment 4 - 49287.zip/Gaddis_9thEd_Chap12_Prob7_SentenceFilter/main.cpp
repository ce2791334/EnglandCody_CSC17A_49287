/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 14, 2020, 9:27 PM
 * Purpose: Filter sentences to control capitalization
 */

//System libraries
#include <fstream>
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions
//Sturctures 

//Function prototypes
void dFile(fstream &);
void rdWrt(fstream &,fstream &);

int main(int argc, char** argv) {
    //Declare variables
    string flNm1,
           flNm2;
    fstream inFile,
            otFile;
    
    //Ask user for input and output file names
    cout << "Enter the names of your input and output "
         << "files:\n";
    
    cin >> flNm1 >> flNm2;
    //Open files to read from and write to
    inFile.open(flNm1, ios::in);
    otFile.open(flNm2, ios::out);
    //Display contents of file 1
    cout << "Here is the original file:" << endl;
    dFile(inFile);
    //Get file 1 then format and write to file 2
    rdWrt(inFile, otFile);

    //Close files
    inFile.close();
    otFile.close();
    
    return 0;
}

//Begin fxn to read in file
void rdWrt(fstream &inFile,fstream &otFile)
{
    //Declare fxn variables
    string line,
           check = "check";  //Character to hold each read in
              //letter from file
    inFile.clear();
    inFile.seekp(0, ios::beg);
    if(inFile)
    {
      cout << "Here is the new file:" << endl;
      //Loop to format file 1 and write to file 2
      while(inFile)
      {
        //Get the first character of the sentence and convert
        //it to an uppercase character
        getline(inFile, line);
        line[0] = toupper(line[0]);
        if(check == line)
            break;

        //For loop to change the rest of each sentence to 
        //lowercase and write it to a new file
        for(int i = 0; i < line.size(); i++)
        {
            if(i > 0)
              line[i] = tolower(line[i]);
      
            
            otFile.put(line[i]);
                
        cout << line[i];
        }

        cout << endl;
        check = line;
       
      }
    }
    else
        cout << "Couldn't open file 1...\n";
}

//Begin fxn to display the file
void dFile(fstream &file)
{
    //Declare fxn variables
    string line;
    file.seekp(0, ios::beg);
    if(file)
        //Loop to display the entire file
        while(getline(file, line))
        {
         cout << line << endl;
         if(getline(file, line))
         cout << line << endl;
        }
    
    else
        cout << "Couldn't open file 2...\n";
    cout << endl;
}