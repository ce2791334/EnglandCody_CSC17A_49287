/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 19, 2020, 7:28 PM
 * Purpose: Calculate the mean, median, and modes 
 * of an array
 */
//Libraries
#include <iostream>//I/O
using namespace std;

//User Libraries
#include "Array.h"
#include "Stats.h"

//No Global Constants

//Function Prototypes I supply
Array *fillAry(int,int);        //Fill an array and put into a structure
void prntAry(const Array *,int);//Print the array 
int *copy(const int *,int);     //Copy the array
void mrkSort(int *,int);        //Sort an array
void prtStat(const Stats *);    //Print the structure
void rcvrMem(Array *);          //Recover memory from the Array Structure
void rcvrMem(Stats *);          //Recover memory from Statistics Structure

//Functions you are to supply
Stats *stat(const Array *);     //Find & store mean, median, & modes in structure

//Execution begins here
int main(int argc, char*argv[]) {
    //Declare variables
    int arySize;//Array Size
    int modNum; //Number to control the modes (digits 0 to 9 allowed)
    Array *array;
    
    //Input the size and mod number
    cout<<"This program develops an array to be analyzed"<<endl;
    cout<<"Array size from mod number to 100"<<endl;
    cout<<"Mod number from 2 to 10"<<endl;
    cout<<"Input the Array Size and the mod number to be used."<<endl;
    cin>>arySize>>modNum;
    cout<<endl<<endl;
    
    //Fill the array
    array=fillAry(arySize,modNum);
    
    //Print the initial array
    cout<<"Original Array before sorting"<<endl;
    prntAry(array,10);
    
    //Sort the array
    mrkSort(array->data,array->size);
    cout<<"Sorted Array to be utilized for the stat function"<<endl;
    prntAry(array,10);
    
    //Calculate some of the statistics
    Stats *stats=stat(array);
    
    //Print the statistics
    prtStat(stats);
    
    //Recover allocated memory
    rcvrMem(array);
    rcvrMem(stats);
    
    //Exit stage right
    return 0;
}

int *copy(const int *a,int n){
    //Declare and allocate an array
    //that is a c
    int *b=new int[n];
    //Fill
    for(int i=0;i<n;i++){
        b[i]=a[i];
    }
    //Return the copy
    return b;
}

void prtStat(const Stats *ary){
    cout<<endl;
    cout<<"The average of the array = "<<ary->avg<<endl;
    cout<<"The median of the array  = "<<ary->median<<endl;
    cout<<"The number of modes      = "<<
            ary->mode->size<<endl;
    cout<<"The max Frequency        = "<<
            ary->modFreq<<endl;
    if(ary->mode->size==0){
        cout<<"The mode set             = {null}"<<endl;
        return;
    }
    cout<<"The mode set             = {";
    for(int i=0;i<ary->mode->size-1;i++){
        cout<<ary->mode->data[i]<<",";
    }
    cout<<ary->mode->data[ary->mode->size-1]<<"}"<<endl;
}

void mrkSort(int *array,int n){
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            if(array[j]<array[i]){
                int temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
    }
}

void rcvrMem(Stats *stats){
    rcvrMem(stats->mode);
    delete stats;
}

void rcvrMem(Array *array){
    delete []array->data;
    delete array;
}

void prntAry(const Array *array,int perLine){
    //Output the array
    for(int i=0;i<array->size;i++){
        cout<<array->data[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

Array *fillAry(int n, int modNum){
    //Allocate memory
    Array *array=new Array;
    array->size=n;
    array->data=new int[array->size];
    
    //Fill the array with mod numbers
    for(int i=0;i<n;i++){
        array->data[i]=i%modNum;
    }
    
    //Exit function
    return array;
}

Stats *stat(const Array *array){
    //Declare fxn variables
    int count = 0;
    float arySum = 0;
    //Non-working stub to be completed by the student         //Now working
    cout<<endl<<"Stat function to be completed by the student"
              << " (now complete)" << endl;
    //Copy existing array to analyze stats
    Stats *stats=new Stats;
    stats->mode=new Array;
    //Initialize number of modes and frequency 
    //with minimum value
    //stats->mode->size=0;
    stats->modFreq = 1;
    int nModes=0;
    
    //Loop through array to analyze numbers
    for (int i=0;i<array->size; i++)
    { 
        //Increment the repeated value count if adjacent numbers
        //are the same
        if (*(array->data + i) - *(array->data + i + 1) == 0)
          count++;
        else
            if (count >= stats->modFreq - 1 && count != 0){
                
                nModes = ((stats->modFreq == 1) ? 1 :
                         ((count + 1) == stats->modFreq) ? nModes+1 :
                         nModes);
                //Set mode frequency to the highest number of repeated
                //values in the array
                stats->modFreq = count + 1;
                count = 0;
             }
            if (*(array->data + i) != *((array->data + i + 1)))
            count = 0;
        //Sum the array contents to calculate average and median
        arySum += array->data[i];
    } 
    //Send the final number of modes to the array
    stats->mode->size=nModes;
    if(nModes!=0)
    {
        //Create dynamic array to hold mode values
        stats->mode->data=new int[nModes];
        //Loop to write in the mode values
        for ( int k = 0; k < nModes; k++)
         stats->mode->data[k] = k;
    }
    //Calculate array average and median 
    stats->avg = arySum / array->size * 1.00;
    int val = stats->avg;
    stats->median = ((stats->avg - val == 0.5) ? stats->avg :
                      array->data[array->size/2]);
    return stats;
}