/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 19, 2020, 7:28 PM
 * Purpose: Encrypt and decrypt data
 */

//System Libraries
#include <iostream>  //I/O
#include <cstring>   //String datatpyes
using namespace std;
//User Libraries - None
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
void encrypt();
void swap(int *,const char);
void print(int *);
void decrypt();
//Execution begins here
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare variables or constants here
    //7 characters or less
    unsigned char choice;
    //Initialize or input data here
    //Ask user for task to perform
    cout << "So you want to work with encrypted data do you?\n\n";
    
    do{
        cout << "\nEnter '1' if you want to encrypt a number and" 
             << "\n'2' if you want to decrypt a number:" << endl;
        cin >> choice;
        switch(choice){
            case '1': {encrypt();break;}
            case '2': {decrypt();break;}
            default: cout << "Fine, no more encryption" << endl;;
        }
    }while(choice == '1' || choice == '2');
   
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    
    //Exit Program 4 
    return 0;
}

//Begin fxn to get the value to encrypt
void encrypt()
{
   //Declare fxn variables
   string num;
   //Obtain number to encrypt
   cout << "Using only the digits 0-7, enter the 4-digit "
         << "number that you want to encrypt:\n";
    cin >> num;
    int *ary = new int[num.length()];
    //Encrypt data
    for(int i = 0; i < num.length(); i++){
        int val = static_cast<int>(num[i]) + 5;
        val = val%8;
        ary[i] = val;
    }
    cout << "\nHere is your new encrypted number:" << endl;
    //Swap values in the array to complete encryption
    swap(ary, num.length());
    
    //Delete allocated memory
    delete []ary;
}

//Begin fxn to swap array values
void swap(int *ary,const char size)
{
    //Swap array values 1 and 3
    int temp = ary[0];
        ary[0] = ary[2];
        ary[2] = temp;
        //Swap array values 2 and 4
        temp = ary[1];
        ary[1] = ary[3];
        ary[3] = temp;
        //Loop to display the encrypted or decrypted number
        for(int i = 0; i < size; i++){
        cout <<ary[i];
        //Account for a potential error
        if(ary[i] == 8 || ary[i] == 9)
            cout << "ERROR: numbers 8 and/or 9 detected" << endl;
        }
        cout << endl;
        
}

//Begin fxn to print encrypted or decrypted value
void print(int *);

//Begin fxn to decrypt a number
void decrypt()
{
    string dnum;
    //Decrypt
    cout << "Using only the digits 0-7, enter the 4-digit "
         << "number that you want to decrypt:\n";
    cin >> dnum;
    int *ary = new int[dnum.length()];
    //Encrypt data
    for(int i = 0; i < dnum.length(); i++){
        int val = static_cast<int>(dnum[i]) - 5;
        val = val%8;
        ary[i] = val;
    }
    cout << "\nHere is your new decrypted number:" << endl;
    //Swap values in the array to complete encryption
    swap(ary, dnum.length());
    
    //Delete allocated memory
    delete []ary;
}