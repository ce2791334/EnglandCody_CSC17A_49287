/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 19, 2020, 7:28 PM
 * Purpose: Break a number into its prime value
 */

//System Libraries
#include <iostream>  //I/O

using namespace std;
//User Libraries - None
#include "Primes.h"
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
Primes *factor(int); // Input an integer, return all prime factors
void prntPrm(Primes *); // Output all prime factors
void destroy(Primes *); //Delete allocated memory
//Execution begins here
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare variables or constants here
    //7 characters or less
    unsigned int num;
    Primes *ary;
    //Initialize or input data here
    
    //Display initial conditions, headings here
    cout << "Input a number between 2 and 10000 for me to\n" 
         << "factor into prime numbers:" << endl;
    cin >> num;
    //Check if input value is within range
    if(num < 2 || num > 10000)
    {
        cout << "What are you nuts!? I told you I'm not factoring that!"
             << endl;
    }
    else 
        ary = factor(num);
    //Process inputs  - map to outputs here
  
    //Format and display outputs here
    if(ary->prime[0].prime == num)
    {
        cout << num << " = " << num << "^1" << endl;
        cout << "This number is already a prime!" << endl;
    }
    else 
    {
        cout << num << " = ";
        prntPrm(ary);
    }
    //Delete allocated memory
    destroy(ary);
    //Exit Problem 7
    return 0;
}

//Begin fxn to split a number into its prime values
Primes *factor(int num)
{
    //declare fxn variables and constants
    const char SIZE = 20;
    int posn = 0;
    int fctr = num;
    int nPrms = 0;
    //Allocate dynamic arrays
    Primes *primes = new Primes; 
    
    for(int i = 2; i < num/2; i++)
    {
        //If the number % an number == 0, then we can factor
        if(fctr % i == 0)
        {
            while(fctr % i == 0)
             fctr = fctr/i;
      
            nPrms++;
        }  
    }
    //Reset factor variable
    fctr = num;
    primes->nPrimes = nPrms;
   //Get an array of structures
    primes->prime = new Prime[primes->nPrimes]; 
    //Initialize primes with result if input is already a prime
    primes->prime[posn].prime = num;
    primes->prime[posn].power = 1;    
    //For loop to factor entire number
    for(int i = 2; i < num/2; i++)
    {
        int exp = 1;
        //If the number % an number == 0, then we can factor
        if(fctr % i == 0)
        {
            primes->prime[posn].prime = i;      //Record value of factor
            //Loop to determine how may times the factor goes into our
            //original number
            while(fctr % i == 0)
            {
                primes->prime[posn].power = exp;  //Record exponent of factor
                //cout << primes->prime[posn].power << "  ";
                    fctr = fctr/i;
                    exp++;
            }
            posn++;
        }                
    }
    return primes;
}

// Begin fxn to output all prime factors
void prntPrm(Primes *primes)
{
    for(int i = 0; i < primes->nPrimes - 1; i++)
    {
        cout << primes->prime[i].prime << "^" 
             << static_cast<int>(primes->prime[i].power)
             << " * ";
    }
    cout << primes->prime[primes->nPrimes - 1].prime << "^" 
         << static_cast<int>(primes->prime[primes->nPrimes - 1].power);
}

//Begin fxn to destroy allocated memory
void destroy(Primes *primes){
    //Clean Up the Dynamic Stuff

    delete [] primes->prime;//Now the array of Structures
    delete primes;//Now deallocate the final Movie Structure
}