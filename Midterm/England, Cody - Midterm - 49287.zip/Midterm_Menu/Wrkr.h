/* 
 * File:   Wrkr.h
 * Author: Cody England
 * Created on October 20, 2020, 5:01 PM
 */

#ifndef WRKR_H
#define WRKR_H

struct Wrkr{
    string empName;         //Employee's name
    short hrsWrkd;          //Hours employee worked
    float payRt;            //Pay rate
};

#endif /* WRKR_H */

