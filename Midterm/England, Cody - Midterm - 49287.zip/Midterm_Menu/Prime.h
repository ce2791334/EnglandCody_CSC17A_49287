/* 
 * File:   Prime.h
 * Author: Cody England
 * Created on October 22, 2020, 6:49 PM
 */

#ifndef PRIME_H
#define PRIME_H

struct Prime{
	unsigned short prime;
	unsigned char power;
};
#endif /* PRIME_H */

