/* 
 * File:   MBudget.h
 * Author: cody England
 * Created on October 19, 2020, 7:35 PM
 */

#ifndef MBUDGET_H
#define MBUDGET_H

struct MBudget{
    string Name;
    string Adrs;
    int   AcntNum;
    float StBal;
    float Chks;
    float Depos;
};

#endif /* MBUDGET_H */

