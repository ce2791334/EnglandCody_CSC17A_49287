/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on Oct. 19 2020 at 7:17PM
 * Purpose:  Menu using Functions,
 *           extended for midterm
 */

//System Libraries
#include <iostream> //I/O
#include <cstring>  //Access string datatypes
#include <iomanip>  //Formatting
using namespace std;

//User Libraries
#include "MBudget.h"
#include "Company.h"
#include "Primes.h"
#include "Prime.h"
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void menu();
void prblm1();
void prblm2();
void prblm3();
void prblm4();
void prblm5();
void prblm6();
void prblm7();
//Problem 1 prototypes
MBudget *info();                     //Get user's personal info
void monAct(MBudget *);           //Get user's withdrawals and
                                     //deposits for the month
void analyze(MBudget *acnt);
//Problem 2 Prototypes
Company *empDat();                               //Retrieve employee data
void calcPay(Company *,const int);               //Calculate paycheck
void destroy(Company *);                         //Delete allocated memory 
void display(Company *,const float,const int);   //Print employees paycheck
void engConv(const float);                       //Determine English 
                                                 //representation of pay
//Function 4 Prototypes
void encrypt();
void swap(int *,const char);
void print(int *);
void decrypt();
//Function Prototypes
Primes *factor(int); // Input an integer, return all prime factors
void prntPrm(Primes *); // Output all prime factors
void destroy(Primes *); //Delete allocated memory

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Loop and Display menu
    do{
        menu();
        cin>>choice;

        //Process/Map inputs to outputs
        switch(choice){
            case '1':{prblm1();break;}
            case '2':{prblm2();break;}
            case '3':{prblm3();break;}
            case '4':{prblm4();break;}
            case '5':{prblm5();break;}
            case '6':{prblm6();break;}
            case '7':{prblm7();break;}
            default: cout<<"Exiting Menu"<<endl;
        }
    }while(choice>='1'&&choice<='7');
    
    //Exit stage right!
    return 0;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Menu
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void menu(){
    //Display menu
    cout<<endl<<"Choose from the following Menu"<<endl;
    cout<<"Type 1 for Problem 1"<<endl;
    cout<<"Type 2 for Problem 2"<<endl;
    cout<<"Type 3 for Problem 3"<<endl;
    cout<<"Type 4 for Problem 4"<<endl;
    cout<<"Type 5 for Problem 5"<<endl;
    cout<<"Type 6 for Problem 6"<<endl;
    cout<<"Type 7 for Problem 7"<<endl<<endl;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 1
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm1(){
    cout<<"Problem 1"<<endl;
  
//Execution Begins Here
//Clear buffer from previous problems
    cin.ignore();
    //Declare Variable Data Types and Constants
    MBudget *Custmr;
    //Get account info
    Custmr = info();
    //Get what was spent and deposited this month
    monAct(Custmr);
    //Check new balance vs. old 
    analyze(Custmr);
    //Process or map Inputs to Outputs
    //Delete allocated memory
    delete Custmr;
    //Exit Problem 1
}

//Begin fxn to obtain user's account information
MBudget *info()
{
    MBudget *Info = new MBudget;
    //Get account info from user
    cout << "Enter you name:\n";
    cout << "Enter your address:\n";
    cout << "Enter your account number:\n";
    cin.ignore();
    getline(cin, Info->Name);
    getline(cin, Info->Adrs);
    cin >> Info->AcntNum;
    //Check that account number is 5 digits long
    if(Info->AcntNum / 10000 < 1 || Info->AcntNum / 100000 >= 1)
    {
        do{
        cout << "Try again, Please enter your five "
             << "digit account number:\n";
        cin >> Info->AcntNum;
        }while(Info->AcntNum / 10000 < 1 || Info->AcntNum / 100000 >= 1);
    }
    cout << "Enter the balance in your account at the "
         << "beginning of the month:\n";
    cin >> Info->StBal;
    
    return Info;
}

//Begin function to calculate all the checks written and 
//deposited this month
void monAct(MBudget *acnt)
{
    //Declare fxn variables
    unsigned int nChks,
                 nDeps;
    float chk,
          dep,
          totChks = 0,
          totDeps = 0;
    //Ask user for the number of checks they deposited
    cout << "Enter the number of checks you wrote this month\n"
         << "and the number of deposits you made this month:\n";
    cin >> nChks >> nDeps;
    if(nChks != 0)
    {
        cout << "Enter each check amount written:\n";
        //For loop to get each written check value
        for(int i = 0; i < nChks; i++)
        {
            cin >> chk;
            totChks += chk;
        }
    }
    
    if(nDeps != 0)
    {
        cout << "Enter each amount deposited:\n";
        //For loop to get each written check value
        for(int j = 0; j < nDeps; j++)
        {
            cin >> dep;
            totDeps += dep;
        }
    }
    cout << endl << endl;
    //Store expenditures and deposits in structure
    acnt->Chks = totChks;
    acnt->Depos  = totDeps;
}

//Begin fxn to calculate and display the new balance at 
//the end of the month
void analyze(MBudget *acnt)
{
    //Calculate the new balance in the account
    float newBal = acnt->StBal - acnt->Chks + acnt->Depos;
    //Output account information and the new balance
    cout << "Name: " << acnt->Name << "\nAddress: " << acnt->Adrs
         << "\nAccount number: " << acnt->AcntNum << endl
         << "Balance at the beginning of the month: $"
         << fixed << setprecision(2) << setw(8) << acnt->StBal << endl;
    cout << "Your new balance after this month's activity is: $"
         << fixed << setprecision(2) << setw(8) << newBal << endl;
    //Debit account if overdrawn
    if(newBal < 0)
    {
        cout << "Your account was overdrawn and a $20.00 fee\n"
             << "has been accessed from your account.\n"
             << "Your new balance after the charge is: $"
             << fixed << setprecision(2) << setw(8) 
             << newBal - 20.00 << endl;
    }
}


//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 2
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm2(){
    cout<<"Problem 2"<<endl;
   
//Execution begins here
    //Clear out buffer from previous problems
    cin.ignore();
    //Initialize or input data here
    Company *com = empDat();
    //Delete allocated memory
    destroy(com);
    //End Problem 2
}

//begin fxn to get the employee data
Company *empDat()
{
    //Declare fxn variables
    int n = 0;              //Counter for loop
   
    //Dynamically create structure 
    Company *co = new Company;
    //Ask for company name and address
    cout << "Enter your company name:\n"
         << "Enter your company address:\n"
         << "Enter the number of employees you have:\n";
    getline(cin, co->coName);
    getline(cin, co->coAdrs);
    cin >> co->nEmpys;
    cout << endl;
    
    //Dynamically create array of structures
    co->wrkr = new Wrkr[co->nEmpys];
    //Loop to get the employee data for each worker 
    while(n < co->nEmpys)
    {
        cin.ignore();
        //Ask for employee's info
        cout << "Enter employee name:\n"
             << "Enter the number of hours they worked:\n"
             << "Enter their payrate:\n";
        getline(cin, co->wrkr[n].empName);
        cin >> co->wrkr[n].hrsWrkd >> co->wrkr[n].payRt;
        //Print error message if pay rate or hours worked 
        //entered is negative
        if(co->wrkr[n].hrsWrkd < 0 || co->wrkr[n].payRt < 0)
        {
            cout << "Error: can't have a negative values for "
                 << "payrate or number of hours worked" << endl;
            break;
        }
        //Calculate the employee's pay
        calcPay(co, n);
        n++;
    }
    //Exit function
    return co;
}

//Begin fxn to calculate the employee's pay
void calcPay(Company *co, const int n)
{
    //Declare fxn variables and constants
    const int NTIME = 40;
    const int DTIME = 50;
    float pay = 0;
    //Initialize variables 
    float dRt = co->wrkr[n].payRt * 2;      //Double time pay rate
    float tRt = co->wrkr[n].payRt * 3;      //Triple time pay rate
    //If hours worked < 40 then caclulate with normal pay rate
    if(co->wrkr[n].hrsWrkd <= NTIME)
        pay = co->wrkr[n].hrsWrkd * co->wrkr[n].payRt;
    else if(co->wrkr[n].hrsWrkd > NTIME && co->wrkr[n].hrsWrkd <= DTIME)
    {
        pay = (NTIME * co->wrkr[n].payRt)
              + ((co->wrkr[n].hrsWrkd - NTIME) * dRt);
    }
     else if(co->wrkr[n].hrsWrkd > DTIME)
     {
         pay = (NTIME * co->wrkr[n].payRt)
              + ((DTIME - NTIME) * dRt)
              + ((co->wrkr[n].hrsWrkd - DTIME) * tRt);
     }
    if(pay != 0)
    display(co, pay, n);
    else cout << "\nThey earned nothing so no paycheck to write\n";
}

//Begin fxn to delete allocated memory
void destroy(Company *com)
{
    delete []com->wrkr;     //Delete the array of structures
    delete com;             //Deallocate the final company structure
}

//Begin fxn to print employee's paycheck
void display(Company *co, const float pay, const int n)
{
     cout << endl << co->coName << endl << co->coAdrs << endl 
          << endl << "Pay to: " << co->wrkr[n].empName << setw(12)
          << setw(30) << "$" << fixed << setprecision(2) << pay
          << endl;
    //determine English of numerical value
          engConv(pay);
    
    cout << setw(24) << "X" << right << setw(14) << "Employer" 
         << " signature" << endl << setw(50) 
         << "-------------------------\n\n";
}

//Begin fxn to determine the English representation of the pay
void engConv(const float pay)
{
     //Declare Variable Data Types and Constants
    unsigned short n2Cnvrt;
    
    n2Cnvrt = pay;
    //Check for a valid input
    if(n2Cnvrt>=1 && n2Cnvrt<=3000){ 
    //Process or map Inputs to Outputs
        //Determine 1000's, 100's, 10's, 1's
        unsigned short n1000s,n100s,n10s,n1s,nos,nts;
        n1000s=n2Cnvrt/1000;   //Shift 3 places to the left
        n100s=n2Cnvrt%1000/100;//Remainder of division of 1000 then shift 2 left
        n10s=n2Cnvrt%100/10;   //Remainder of division of 100 then shift 1 left
        n1s=n2Cnvrt%10;        //Remainder of division by 1
        //Output the number of 1000's in Roman Numerals
        //Using the Switch Statement
        switch(n1000s){
            case 3:cout<<"Three thousand ";break;
            case 2:cout<<"Two thousand ";break;
            case 1:cout<<"One thousand ";break;
        }
        
        //Output the number of 100's
        //Using the Ternary Operator
        cout<<(n100s==9?"nine hundred ":
               n100s==8?"eight hundred ":
               n100s==7?"seven hundred ":
               n100s==6?"six hundred ":
               n100s==5?"five hundred ":
               n100s==4?"four hundred ":
               n100s==3?"three hundred ":
               n100s==2?"two hundred ":
               n100s==1?"one hundred ":"");
        
        //Output the number of 10's
        //Using Independent If Statements
        if(n10s==9)cout<<"ninety ";
        if(n10s==8)cout<<"eighty ";
        if(n10s==7)cout<<"seventy ";
        if(n10s==6)cout<<"sixty ";
        if(n10s==5)cout<<"fifty ";
        if(n10s==4)cout<<"forty ";
        if(n10s==3)cout<<"thirty ";
        if(n10s==2)cout<<"twenty ";
        if(n10s==1)
        {
        if(n1s==9)cout<<"nineteen";
        else if(n1s==8)cout<<"eighteen ";
        else if(n1s==7)cout<<"seventeen ";
        else if(n1s==6)cout<<"sixteen ";
        else if(n1s==5)cout<<"fifteen ";
        else if(n1s==4)cout<<"fourteen ";
        else if(n1s==3)cout<<"thirteen ";
        else if(n1s==2)cout<<"twelve ";
        else if(n1s==1)cout<<"eleven ";
        else if(n1s==0)cout<<"ten ";
        }
        
        //Output the number of 1's
        //Using Dependent If Statements
        if(n10s!=1)
        {
        if(n10s > 0)cout <<"- ";
        if(n1s==9)cout<<"nine ";
        else if(n1s==8)cout<<"eight ";
        else if(n1s==7)cout<<"seven ";
        else if(n1s==6)cout<<"six ";
        else if(n1s==5)cout<<"five ";
        else if(n1s==4)cout<<"four ";
        else if(n1s==3)cout<<"three ";
        else if(n1s==2)cout<<"two ";
        else if(n1s==1)cout<<"one ";
        }
        
        //Determine cents
            float val = ((pay - n2Cnvrt) * 100);
            if(val >= 10)
            {
                cout << fixed << setprecision(0) 
                 << val << "/100" 
                 << endl;
            }
            else if(val > 0)
            {
                cout << fixed << setprecision(0) 
                     << "0" << val << "/100" 
                     << endl;
            } 
            else cout << "00/100" << " dollars" << endl;
         
    //The Path to Exit
    }else{
        cout<<"Ya right they got paid that much"<<endl;
    }
}


//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 3
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm3(){
    cout<<"Problem 3"<<endl;
    
    cout << "Included in 'Midterm_Prob3' project." << endl << endl;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 4
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm4(){
    cout<<"problem 4"<<endl;

//Execution begins here
    //Clear out buffer from previous problems
    cin.ignore();
    //Declare variables or constants here
    //7 characters or less
    unsigned char choice;
    //Ask user for task to perform
    cout << "So you want to work with encrypted data do you?\n\n";
    
    do{
        cout << "\nEnter '1' if you want to encrypt a number and" 
             << "\n'2' if you want to decrypt a number:" << endl;
        cin >> choice;
        switch(choice){
            case '1': {encrypt();break;}
            case '2': {decrypt();break;}
            default: cout << "Fine, no more encryption" << endl;;
        }
    }while(choice == '1' || choice == '2');
    //Exit Program 4 
}

//Begin fxn to get the value to encrypt
void encrypt()
{
   //Declare fxn variables
   string num;
   //Obtain number to encrypt
   cout << "Using only the digits 0-7, enter the 4-digit "
         << "number that you want to encrypt:\n";
    cin >> num;
    int *ary = new int[num.length()];
    //Encrypt data
    for(int i = 0; i < num.length(); i++){
        int val = static_cast<int>(num[i]) + 5;
        val = val%8;
        ary[i] = val;
    }
    cout << "\nHere is your new encrypted number:" << endl;
    //Swap values in the array to complete encryption
    swap(ary, num.length());
    
    //Delete allocated memory
    delete []ary;
}

//Begin fxn to swap array values
void swap(int *ary,const char size)
{
    //Swap array values 1 and 3
    int temp = ary[0];
        ary[0] = ary[2];
        ary[2] = temp;
        //Swap array values 2 and 4
        temp = ary[1];
        ary[1] = ary[3];
        ary[3] = temp;
        //Loop to display the encrypted or decrypted number
        for(int i = 0; i < size; i++){
        cout <<ary[i];
        //Account for a potential error
        if(ary[i] == 8 || ary[i] == 9)
            cout << "ERROR: numbers 8 and/or 9 detected" << endl;
        }
        cout << endl;
        
}

//Begin fxn to print encrypted or decrypted value
void print(int *);

//Begin fxn to decrypt a number
void decrypt()
{
    string dnum;
    //Decrypt
    cout << "Using only the digits 0-7, enter the 4-digit "
         << "number that you want to decrypt:\n";
    cin >> dnum;
    int *ary = new int[dnum.length()];
    //Encrypt data
    for(int i = 0; i < dnum.length(); i++){
        int val = static_cast<int>(dnum[i]) - 5;
        val = val%8;
        ary[i] = val;
    }
    cout << "\nHere is your new decrypted number:" << endl;
    //Swap values in the array to complete encryption
    swap(ary, dnum.length());
    
    //Delete allocated memory
    delete []ary;
}


//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 5
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm5(){
    cout<<"problem 5"<<endl;
    //Format and display outputs here
    cout << "The largest n such that n! can be calculated is:\n";
    cout << "For the signed 'char' datatype, n = 5" << endl;
    cout << "For the unsigned 'char' datatype, n = 5" << endl;
    cout << "For the signed 'short' datatype, n = 7" << endl;
    cout << "For the unsigned 'short' datatype, n = 8" << endl;
    cout << "For the signed 'int' datatype, n = 13" << endl;
    cout << "For the unsigned 'int' datatype, n = 15" << endl;
    cout << "For the signed 'long' datatype, n = 20" << endl;
    cout << "For the unsigned 'long' datatype, n = 22" << endl;
    cout << "For the 'float' datatype, n = 34" << endl;
    cout << "For the 'double' datatype, n = 170" << endl;
    //Exit Problem 5
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 6
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm6(){
    cout<<"problem 6"<<endl;
    
    //Format and display outputs here
    cout << "2.875 Base 10: 2 in Base 10 = 0100000000"
         << "0000000000000000000010 in binary,\n40000002 in hex, "
         << "and 20000000002 in octal.\n0.875 in Base 10 = "
         << "01110000000000000000000000000000 in binary\n"
         << "E0000000 in hex, and 34000000000 in octal" 
         << endl << endl;;
    cout << "0.1796875 Base 10 01011100000000000000000010000011 "
         << "in binary\n5C000082 in hex, and 270000000402 in octal"
         << endl << endl;
    cout << "-2.875 in Base 10: -2 in Base 10 = 01110000"
         << "000000000000000000000000 in binary,\nE0000000 in hex, "
         << "and 34000000000 in octal.\n-0.875 Base 10 = "
         << "1101110000000000000000000000010 in binary,\n"
         << "DC000002 in hex, and 67000000002 in octal"
         << endl << endl;
    cout << "-0.1796875 Base 10 = 11011100000000000000000010000010 "
         << "in binary,\nDC000082 in hex, and 67000000402 in octal" 
         << endl << endl;
    cout << "59999901 in hex = ~1.4 Base 10" << endl << endl;
    cout << "59999902 = ~2.8 Base 10" << endl << endl;
    cout << "A66667FE in hex = -0.1624995 in Base 10" << endl;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 7
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm7(){
    cout<<"problem 7"<<endl;
 
//Execution begins here
 //Clear buffer from previous problems
    cin.ignore();
    //Declare variables or constants here
    //7 characters or less
    unsigned int num;
    Primes *ary;
    //Display initial conditions, headings here
    cout << "Input a number between 2 and 10000 for me to\n" 
         << "factor into prime numbers:" << endl;
    cin >> num;
    //Check if input value is within range
    if(num < 2 || num > 10000)
    {
        cout << "What are you nuts!? I told you I'm not factoring that!"
             << endl;
    }
    else 
        ary = factor(num);
    //Format and display outputs here
    if(ary->prime[0].prime == num)
    {
        cout << num << " = " << num << "^1" << endl;
        cout << "This number is already a prime!" << endl;
    }
    else 
    {
        cout << num << " = ";
        prntPrm(ary);
    }
    //Delete allocated memory
    destroy(ary);
    //Exit Problem 7
}

//Begin fxn to split a number into its prime values
Primes *factor(int num)
{
    //declare fxn variables and constants
    const char SIZE = 20;
    int posn = 0;
    int fctr = num;
    int nPrms = 0;
    //Allocate dynamic arrays
    Primes *primes = new Primes; 
    
    for(int i = 2; i < num/2; i++)
    {
        //If the number % an number == 0, then we can factor
        if(fctr % i == 0)
        {
            while(fctr % i == 0)
             fctr = fctr/i;
      
            nPrms++;
        }  
    }
    //Reset factor variable
    fctr = num;
    primes->nPrimes = nPrms;
   //Get an array of structures
    primes->prime = new Prime[primes->nPrimes]; 
    //Initialize primes with result if input is already a prime
    primes->prime[posn].prime = num;
    primes->prime[posn].power = 1;    
    //For loop to factor entire number
    for(int i = 2; i < num/2; i++)
    {
        int exp = 1;
        //If the number % an number == 0, then we can factor
        if(fctr % i == 0)
        {
            primes->prime[posn].prime = i;      //Record value of factor
            //Loop to determine how may times the factor goes into our
            //original number
            while(fctr % i == 0)
            {
                primes->prime[posn].power = exp;  //Record exponent of factor
                //cout << primes->prime[posn].power << "  ";
                    fctr = fctr/i;
                    exp++;
            }
            posn++;
        }                
    }
    return primes;
}

// Begin fxn to output all prime factors
void prntPrm(Primes *primes)
{
    for(int i = 0; i < primes->nPrimes - 1; i++)
    {
        cout << primes->prime[i].prime << "^" 
             << static_cast<int>(primes->prime[i].power)
             << " * ";
    }
    cout << primes->prime[primes->nPrimes - 1].prime << "^" 
         << static_cast<int>(primes->prime[primes->nPrimes - 1].power);
}

//Begin fxn to destroy allocated memory
void destroy(Primes *primes){
    //Clean Up the Dynamic Stuff

    delete [] primes->prime;//Now the array of Structures
    delete primes;//Now deallocate the final Movie Structure
}

