/* 
 * File:   Company.h
 * Author: Cody England
 * Created on October 20, 2020, 4:54 PM
 */

#ifndef COMPANY_H
#define COMPANY_H

#include "Wrkr.h"

 struct Company{

     string coName;
     string coAdrs;
     int nEmpys;
     
     Wrkr *wrkr;

};


#endif /* COMPANY_H */


