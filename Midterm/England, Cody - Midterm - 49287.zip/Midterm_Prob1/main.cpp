/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 19, 2020, 7:28 PM
 * Purpose: Use a dynamic structure to calculate an 
 * account balance after a month's activity
 */

//System Libraries
#include <iostream> //I/O
#include <cstring>  //Access string datatypes
#include <iomanip>  //Formatting

using namespace std;

//User Libraries
#include "MBudget.h"
//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
MBudget *info();                     //Get user's personal info
void monAct(MBudget *);           //Get user's withdrawals and
                                     //deposits for the month
void analyze(MBudget *acnt);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    MBudget *Custmr;
    //Initialize Variables
    
    //Get account info
    Custmr = info();
    //Get what was spent and deposited this month
    monAct(Custmr);
    //Check new balance vs. old 
    analyze(Custmr);
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Delete allocated memory
    delete Custmr;
    //Exit stage right!
    return 0;
}

//Begin fxn to obtain user's account information
MBudget *info()
{
    MBudget *Info = new MBudget;
    //Get account info from user
    cout << "Enter you name:\n";
    cout << "Enter your address:\n";
    cout << "Enter your account number:\n";
    getline(cin, Info->Name);
    getline(cin, Info->Adrs);
    cin >> Info->AcntNum;
    //Check that account number is 5 digits long
    if(Info->AcntNum / 10000 < 1 || Info->AcntNum / 100000 >= 1)
    {
        do{
        cout << "Try again, Please enter your five "
             << "digit account number:\n";
        cin >> Info->AcntNum;
        }while(Info->AcntNum / 10000 < 1 || Info->AcntNum / 100000 >= 1);
    }
    cout << "Enter the balance in your account at the "
         << "beginning of the month:\n";
    cin >> Info->StBal;
    
    return Info;
}

//Begin function to calculate all the checks written and 
//deposited this month
void monAct(MBudget *acnt)
{
    //Declare fxn variables
    unsigned int nChks,
                 nDeps;
    float chk,
          dep,
          totChks = 0,
          totDeps = 0;
    //Ask user for the number of checks they deposited
    cout << "Enter the number of checks you wrote this month\n"
         << "and the number of deposits you made this month:\n";
    cin >> nChks >> nDeps;
    if(nChks != 0)
    {
        
        cout << "Enter each check amount written:\n";
        //For loop to get each written check value
        for(int i = 0; i < nChks; i++)
        {
            cin >> chk;
            totChks += chk;
        }
    }
    
    if(nDeps != 0)
    {
        cout << "Enter each amount deposited:\n";
        //For loop to get each written check value
        for(int j = 0; j < nDeps; j++)
        {
            cin >> dep;
            totDeps += dep;
        }
    }
    cout << endl << endl;
    //Store expenditures and deposits in structure
    acnt->Chks = totChks;
    acnt->Depos  = totDeps;
}

//Begin fxn to calculate and display the new balance at 
//the end of the month
void analyze(MBudget *acnt)
{
    //Format output
    float newBal = acnt->StBal - acnt->Chks + acnt->Depos;
    cout << "Name: " << acnt->Name << "\nAddress: " << acnt->Adrs
         << "\nAccount number: " << acnt->AcntNum << endl
         << "Balance at the beginning of the month: $"
         << fixed << setprecision(2) << setw(8) << acnt->StBal << endl;
    cout << "Your new balance after this month's activity is: $"
         << fixed << setprecision(2) << setw(8) << newBal << endl;
    //Debit account if overdrawn
    if(newBal < 0)
    {
        cout << "Your account was overdrawn and a $20.00 fee\n"
             << "has been accessed from your account.\n"
             << "Your new balance after the charge is: $"
             << fixed << setprecision(2) << setw(8) 
             << newBal - 20.00 << endl;
    }
}
 