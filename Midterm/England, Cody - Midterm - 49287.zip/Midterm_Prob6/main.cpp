/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 22, 2020, 10:38 PM
 * Output Problem 6
 */
//System Libraries
#include <iostream>

using namespace std;
//User Libraries - None
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Format and display outputs here
    cout << "2.875 Base 10: 2 in Base 10 = 0100000000"
         << "0000000000000000000010 in binary,\n40000002 in hex, "
         << "and 20000000002 in octal.\n0.875 in Base 10 = "
         << "01110000000000000000000000000000 in binary\n"
         << "E0000000 in hex, and 34000000000 in octal" 
         << endl << endl;;
    cout << "0.1796875 Base 10 01011100000000000000000010000011 "
         << "in binary\n5C000082 in hex, and 270000000402 in octal"
         << endl << endl;
    cout << "-2.875 in Base 10: -2 in Base 10 = 01110000"
         << "000000000000000000000000 in binary,\nE0000000 in hex, "
         << "and 34000000000 in octal.\n-0.875 Base 10 = "
         << "1101110000000000000000000000010 in binary,\n"
         << "DC000002 in hex, and 67000000002 in octal"
         << endl << endl;
    cout << "-0.1796875 Base 10 = 11011100000000000000000010000010 "
         << "in binary,\nDC000082 in hex, and 67000000402 in octal" 
         << endl << endl;
    cout << "59999901 in hex = ~1.4 Base 10" << endl << endl;
    cout << "59999902 = ~2.8 Base 10" << endl << endl;
    cout << "A66667FE in hex = -0.1624995 in Base 10" << endl;
    return 0;
}


