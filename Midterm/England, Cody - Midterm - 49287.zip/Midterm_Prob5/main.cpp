/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 19, 2020, 7:28 PM
 * Purpose: Determine the largest n for different data types
 * where n! will be in the data type's range 
 */

//System Libraries
#include <iostream>

using namespace std;
//User Libraries - None
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare variables or constants here
    //7 characters or less
    
    //Initialize or input data here
    
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    cout << "The largest n such that n! can be calculated is:\n";
    cout << "For the signed 'char' datatype, n = 5" << endl;
    cout << "For the unsigned 'char' datatype, n = 5" << endl;
    cout << "For the signed 'short' datatype, n = 7" << endl;
    cout << "For the unsigned 'short' datatype, n = 8" << endl;
    cout << "For the signed 'int' datatype, n = 13" << endl;
    cout << "For the unsigned 'int' datatype, n = 15" << endl;
    cout << "For the signed 'long' datatype, n = 20" << endl;
    cout << "For the unsigned 'long' datatype, n = 22" << endl;
    cout << "For the 'float' datatype, n = 34" << endl;
    cout << "For the 'double' datatype, n = 170" << endl;
    return 0;
}


