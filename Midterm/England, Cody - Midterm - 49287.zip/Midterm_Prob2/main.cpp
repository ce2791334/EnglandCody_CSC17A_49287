/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 19, 2020, 7:28 PM
 * Purpose: 
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
//User Libraries
#include "Company.h"
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
Company *empDat();                               //Retrieve employee data
void calcPay(Company *,const int);               //Calculate paycheck
void destroy(Company *);                         //Delete allocated memory 
void display(Company *,const float,const int);  //Print employees paycheck
void engConv(const float); //Determine English 
                                                //representation of pay
//Execution begins here
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare variables or constants here
    //7 characters or less
    
    //Initialize or input data here
    Company *com = empDat();
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    //Delete allocated memory
    destroy(com);
    //Exit stage right
    return 0;
}

//begin fxn to get the employee data
Company *empDat()
{
    //Declare fxn variables
    int n = 0;              //Counter for loop
   
    //Dynamically create structure 
    Company *co = new Company;
    //Ask for company name and address
    cout << "Enter your company name:\n"
         << "Enter your company address:\n"
         << "Enter the number of employees you have:\n";
    getline(cin, co->coName);
    getline(cin, co->coAdrs);
    cin >> co->nEmpys;
    cout << endl;
    
    //Dynamically create array of structures
    co->wrkr = new Wrkr[co->nEmpys];
    //Loop to get the employee data for each worker 
    while(n < co->nEmpys)
    {
        cin.ignore();
        //Ask for employee's info
        cout << "Enter employee name:\n"
             << "Enter the number of hours they worked:\n"
             << "Enter their payrate:\n";
        getline(cin, co->wrkr[n].empName);
        cin >> co->wrkr[n].hrsWrkd >> co->wrkr[n].payRt;
        //Print error message if pay rate or hours worked 
        //entered is negative
        if(co->wrkr[n].hrsWrkd < 0 || co->wrkr[n].payRt < 0)
        {
            cout << "Error: can't have a negative values for "
                 << "payrate or number of hours worked" << endl;
            break;
        }
        //Calculate the employee's pay
        calcPay(co, n);
        n++;
    }
    //Exit function
    return co;
}

//Begin fxn to calculate the employee's pay
void calcPay(Company *co, const int n)
{
    //Declare fxn variables and constants
    const int NTIME = 40;
    const int DTIME = 50;
    float pay = 0;
    //Initialize variables 
    float dRt = co->wrkr[n].payRt * 2;      //Double time pay rate
    float tRt = co->wrkr[n].payRt * 3;      //Triple time pay rate
    //If hours worked < 40 then caclulate with normal pay rate
    if(co->wrkr[n].hrsWrkd <= NTIME)
        pay = co->wrkr[n].hrsWrkd * co->wrkr[n].payRt;
    else if(co->wrkr[n].hrsWrkd > NTIME && co->wrkr[n].hrsWrkd <= DTIME)
    {
        pay = (NTIME * co->wrkr[n].payRt)
              + ((co->wrkr[n].hrsWrkd - NTIME) * dRt);
    }
     else if(co->wrkr[n].hrsWrkd > DTIME)
     {
         pay = (NTIME * co->wrkr[n].payRt)
              + ((DTIME - NTIME) * dRt)
              + ((co->wrkr[n].hrsWrkd - DTIME) * tRt);
     }
    if(pay != 0)
    display(co, pay, n);
    else cout << "\nThey earned nothing so no paycheck to write\n";
}

//Begin fxn to delete allocated memory
void destroy(Company *com)
{
    delete []com->wrkr;     //Delete the array of structures
    delete com;             //Deallocate the final company structure
}

//Begin fxn to print employee's paycheck
void display(Company *co, const float pay, const int n)
{
     cout << endl << co->coName << endl << co->coAdrs << endl 
          << endl << "Pay to: " << co->wrkr[n].empName << setw(12)
          << setw(30) << "$" << fixed << setprecision(2) << pay
          << endl;
    //determine English of numerical value
          engConv(pay);
    
    cout << setw(24) << "X" << right << setw(14) << "Employer" 
         << " signature" << endl << setw(50) 
         << "-------------------------\n\n";
}

//Begin fxn to determine the English representation of the pay
void engConv(const float pay)
{
     //Declare Variable Data Types and Constants
    unsigned short n2Cnvrt;
    
    n2Cnvrt = pay;
    //Check for a valid input
    if(n2Cnvrt>=1 && n2Cnvrt<=3000){ 
    //Process or map Inputs to Outputs
        //Determine 1000's, 100's, 10's, 1's
        unsigned short n1000s,n100s,n10s,n1s,nos,nts;
        n1000s=n2Cnvrt/1000;   //Shift 3 places to the left
        n100s=n2Cnvrt%1000/100;//Remainder of division of 1000 then shift 2 left
        n10s=n2Cnvrt%100/10;   //Remainder of division of 100 then shift 1 left
        n1s=n2Cnvrt%10;        //Remainder of division by 1
        //Output the number of 1000's in Roman Numerals
        //Using the Switch Statement
        switch(n1000s){
            case 3:cout<<"Three thousand ";break;
            case 2:cout<<"Two thousand ";break;
            case 1:cout<<"One thousand ";break;
        }
        
        //Output the number of 100's
        //Using the Ternary Operator
        cout<<(n100s==9?"nine hundred ":
               n100s==8?"eight hundred ":
               n100s==7?"seven hundred ":
               n100s==6?"six hundred ":
               n100s==5?"five hundred ":
               n100s==4?"four hundred ":
               n100s==3?"three hundred ":
               n100s==2?"two hundred ":
               n100s==1?"one hundred ":"");
        
        //Output the number of 10's
        //Using Independent If Statements
        if(n10s==9)cout<<"ninety ";
        if(n10s==8)cout<<"eighty ";
        if(n10s==7)cout<<"seventy ";
        if(n10s==6)cout<<"sixty ";
        if(n10s==5)cout<<"fifty ";
        if(n10s==4)cout<<"forty ";
        if(n10s==3)cout<<"thirty ";
        if(n10s==2)cout<<"twenty ";
        if(n10s==1)
        {
        if(n1s==9)cout<<"nineteen";
        else if(n1s==8)cout<<"eighteen ";
        else if(n1s==7)cout<<"seventeen ";
        else if(n1s==6)cout<<"sixteen ";
        else if(n1s==5)cout<<"fifteen ";
        else if(n1s==4)cout<<"fourteen ";
        else if(n1s==3)cout<<"thirteen ";
        else if(n1s==2)cout<<"twelve ";
        else if(n1s==1)cout<<"eleven ";
        else if(n1s==0)cout<<"ten ";
        }
        
        //Output the number of 1's
        //Using Dependent If Statements
        if(n10s!=1)
        {
        if(n10s > 0)cout <<"- ";
        if(n1s==9)cout<<"nine ";
        else if(n1s==8)cout<<"eight ";
        else if(n1s==7)cout<<"seven ";
        else if(n1s==6)cout<<"six ";
        else if(n1s==5)cout<<"five ";
        else if(n1s==4)cout<<"four ";
        else if(n1s==3)cout<<"three ";
        else if(n1s==2)cout<<"two ";
        else if(n1s==1)cout<<"one ";
        }
        
        //Determine cents
            float val = ((pay - n2Cnvrt) * 100);
            if(val >= 10)
            {
                cout << fixed << setprecision(0) 
                 << val << "/100" 
                 << endl;
            }
            else if(val > 0)
            {
                cout << fixed << setprecision(0) 
                     << "0" << val << "/100" 
                     << endl;
            } 
            else cout << "00/100" << " dollars" << endl;
        
            
            
                
    //The Path to Exit
    }else{
        cout<<"Ya right they got paid that much"<<endl;
    }
}