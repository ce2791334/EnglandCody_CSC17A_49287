/* Cody England
 CSC-17A_49287
 Assignment_1_HelloWorld
 08/27/20*/

#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    cout << "Hello World! \nThis is my first 17A Program." << endl;
    
    return 0;
}

