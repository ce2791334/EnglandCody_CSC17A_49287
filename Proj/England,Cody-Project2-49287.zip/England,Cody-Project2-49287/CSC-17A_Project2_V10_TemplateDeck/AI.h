/* 
 * File:   AI.h
 * Author: Cody England
 * Created on December 15, 2020, 1:04 AM
 * Purpose: Specifications for AI class
 */

#ifndef AI_H
#define AI_H

#include <string>
using namespace std;

#include "AbsPlyr.h"

class AI : protected AbsPlyr{
    private:   
        Hand *hand;
    public:
        AI(string);
        //Mutator
        void setHand(Hand *);
        string getName(){return name;}
        void prntHnd();
   
};

#endif /* AI_H */

