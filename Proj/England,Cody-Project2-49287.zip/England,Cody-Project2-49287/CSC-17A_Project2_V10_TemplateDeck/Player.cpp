/* 
 * File:   Player.cpp
 * Author: Cody England
 * Created on December 15, 2020, 12:34 AM
 * Purpose: Specifications for player class
 */

#include "Player.h"

Player::Player(string nm){
    name = nm;
}

void Player::setHand(Hand *hd){
    hand = hd;
}

void Player::prntHnd(){
    hand->display();
}