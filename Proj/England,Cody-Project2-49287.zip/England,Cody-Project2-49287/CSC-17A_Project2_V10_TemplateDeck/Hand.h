/* 
 * File:   Hand.h
 * Author: Cody England
 * Created on December 13, 2020, 11:35 PM
 * Purpose: Specifications for Hand class
 */

#ifndef HAND_H
#define HAND_H

class Hand{
    private:
        unsigned char handSz;
        unsigned char *cards;
    public:
        //Constructor
        Hand(unsigned char *,unsigned char);
        ~Hand(); 
        void display();
};

#endif /* HAND_H */

