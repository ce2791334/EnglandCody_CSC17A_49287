/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 15, 2020, 3:33 AM
 * Purpose: Object Oriented Game of Mao
 * Version 9 - Add AI and Human classes inherited from Player
 */

//System Libraries
#include <iostream>     //I/O library
#include <iomanip>      //I/O formatting library
#include <cstring>      //String library 
using namespace std;

//User Libraries
#include "Deck.h"
#include "Hand.h"
#include "Player.h"
#include "AI.h"
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    
    //Declare Variables
    unsigned char deckSz = 52;  //Standard single deck size
    unsigned char nHnds = 4;    //Number of hands dealt (temp set to 4)
    unsigned char handSz = 12;  //Starting hand size in Mao
    string name;                //Hold player's name
    Deck<Card> deck(deckSz);         
    
    //Initialize Variables (the deck and pointer index)
    deck.shuffle();
    deck.display();
    
    cout << "Enter your name: " << endl;
    getline(cin,name);
    
    //Instantiate player class
    Player plyr1(name);
    AI Ai("Bob");
    //Process inputs to outputs/map
    
    //Display hands 
    Hand hand1(deck.deal(handSz),handSz);
    plyr1.setHand(&hand1);
    cout << plyr1.getName() << "'s hand: " << endl;
    plyr1.prntHnd();
    
    Hand hand2(deck.deal(handSz),handSz);
    Ai.setHand(&hand2);
    cout << Ai.getName() << "'s hand: " << endl;
    Ai.prntHnd();
    
    //Display the results 
    
    //Reallocate memory

    //Exit stage right
    return 0;
}