/* 
 * File:   Player.h
 * Author: Cody England
 * Created on December 15, 2020, 12:34 AM
 * Purpose: Specifications for player class
 */

#ifndef PLAYER_H
#define PLAYER_H

#include <string>
using namespace std;

#include "AbsPlyr.h"

class Player : protected AbsPlyr{
    private:
        Hand *hand;
    public:
        //Constructor
        Player(string);
        //Mutator fxns
        void setHand(Hand *);
        //Accessor fxns
        string getName(){return name;}
        void prntHnd();
     
};

#endif /* PLAYER_H */