/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 10, 2020, 11:52 PM
 * Purpose: Project 2 Game of Mao
 * Version: 1.0 - Begin Project 2; Develop a card.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
char suit(int);
char face(int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Declare Variables
    const char DEKSZ = 52;
    //Initialize Variables
    
    //Process inputs to outputs/map
    for(int i=0;i<DEKSZ;i++){
        cout<<i+1<<" "<<face(i)<<suit(i)<<" "<<endl;
    }
    
    //Display the results

    //Clean up and exit stage right
    return 0;
}

char face(int n){
    n>=0?n%=52:0;
    char faces[]={'A','2','3','4','5','6','7','8','9','T','J','Q','K'};
    return faces[n%13];
}

char suit(int n){
    n>=0?n%=52:0;
    char suits[]={'S','D','C','H'};
    return suits[n/13];
}
