/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 14, 2020, 4:30 PM
 * Purpose: Object Oriented Game of Mao
 * Version 5 - Deal Player hands
 */

//System Libraries
#include <iostream>     //I/O library
#include <cstdlib>      //Standard library for rand fxn
#include <ctime>        //Time library for randomizing of numbers
using namespace std;

//User Libraries
#include "Card.h"
//Global Constants

//Function Prototypes
void shuffle(int *,const unsigned char,const unsigned char);
void destroy(Card **,int *,int *,int *,const unsigned char);
int *deal(int *,const unsigned char,const unsigned char);

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    srand(static_cast<unsigned int>(time(0)));
    //Set constants
    const unsigned char DECKSZ = 52;  //Standard single deck size
    const unsigned char numShfl = 7;  //Standard number of deck shuffles
    const unsigned char HANDSZ = 12;  //Starting hand size
    //Declare Variables
    Card **deck;    //Card deck class
    
    //Initialize Variables (the deck and pointer index)
    int *indx = new int[DECKSZ];    //Index array
    deck = new Card *[DECKSZ];      //Allocate memory for array of 52 card 
                                    //pointers
    for(int i=0;i<DECKSZ;i++){
        deck[i] = new Card(i);      //Create each card
        indx[i] = i;
    }
    //Process inputs to outputs/map
    shuffle(indx,DECKSZ,numShfl);
    for(int i=0;i<DECKSZ;i++){
        cout<<indx[i] + 1<<" "<<deck[indx[i]]->face()<<deck[indx[i]]->suit()
            << " " << endl;
    }
   
    //Deal players
    int *Plyr1 = deal(indx, DECKSZ, HANDSZ);
    int *Plyr2 = deal(indx,DECKSZ,HANDSZ);
    
    
    //Display the results
    
    //Reallocate memory
    destroy(deck, indx, Plyr1, Plyr2, DECKSZ);
    
    //Exit stage right
    return 0;
}

//Begin shuffle fxn
void shuffle(int *indx,const unsigned char n,const unsigned char nShf){
    for(int i = 1; i <= nShf; i++){
        for(int j = 0; j < n; j++){
            int temp=rand()%n;
            int card=indx[j];
            indx[j]=indx[temp];
            indx[temp]=card;
        }
    }
}

//Begin destroy fxn to reallocate memory
void destroy(Card **deck, int *hand1, int *hand2,int *indx, 
                const unsigned char sz)
{
    //Reallocate Memory
    for(int i=0;i<sz;i++){
        delete deck[i];       //Destruction of each individual card
    }
    delete []deck;            //Destruction of the array of pointers
    delete []indx;
    delete []hand1;
    delete []hand2;

}

//Begin fxn to deal hands
int *deal(int *indx,const unsigned char n,const unsigned char hndSz){
    static char delt=0;
    int *hand=new int[hndSz];
    if(delt>52-delt)shuffle(indx,n,7);
    for(int i=0;i<hndSz;i++){
        hand[i]=indx[delt++];
    }
    return hand;
}