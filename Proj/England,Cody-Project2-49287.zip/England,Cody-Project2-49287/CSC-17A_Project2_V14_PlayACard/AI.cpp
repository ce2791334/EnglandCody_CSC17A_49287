/* 
 * File:   AI.cpp
 * Author: Cody England
 * Created on December 15, 2020, 1:04 AM
 * Purpose: Specifications for AI class
 */

#include <iostream>
#include <string>
using namespace std;
#include "AI.h"


AI::AI(string aNm){
    AiNm = aNm;
}

AI::AI(const AI &ai){
    AiNm = ai.AiNm;
}

void AI::setHand(Hand *hd){
     hand = hd;
}

void AI::prntHnd(){
    hand->display();
}


