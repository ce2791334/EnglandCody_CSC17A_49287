 /* 
 * File:   Card.cpp
 * Author: Cody England
 * Created on December 13, 2020, 9:59AM
 * Purpose: Specifications for Card class
 */


#include "Card.h"

Card::Card(unsigned char n)
{
    cardNum = (n>0?n:0);
}

char Card::face()
{
    int n = cardNum;
    n>=0?n%=52:0;
    char faces[]={'A','2','3','4','5','6','7','8','9','T','J','Q','K'};
    return faces[n%13];
}

char Card::suit()
{
    int n = cardNum;
    n>=0?n%=52:0;
    char suits[]={'S','D','C','H'};
    return suits[n/13];
}
