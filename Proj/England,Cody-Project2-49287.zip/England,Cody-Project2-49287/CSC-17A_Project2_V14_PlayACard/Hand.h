/* 
 * File:   Hand.h
 * Author: Cody England
 * Created on December 13, 2020, 11:35 PM
 * Purpose: Specifications for Hand class
 */

#ifndef HAND_H
#define HAND_H

class Hand{
    private:
        unsigned char handSz;
        unsigned char *cards;
    public:
        //Exception classes
        class BadPlay
            {};
        //Constructor
        Hand(unsigned char *,unsigned char);
        ~Hand(); 
        void display();     //Displays hand
        char check(unsigned char, unsigned char); //Checks if card is in hand
        void swap (int); //Swaps card played to back of hand
};

#endif /* HAND_H */

