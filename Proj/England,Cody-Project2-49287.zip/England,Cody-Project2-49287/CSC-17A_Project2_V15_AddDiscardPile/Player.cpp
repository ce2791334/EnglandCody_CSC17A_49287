/* 
 * File:   Player.cpp
 * Author: Cody England
 * Created on December 15, 2020, 12:34 AM
 * Purpose: Specifications for player class
 */
#include <iostream>
using namespace std;
#include "Player.h"
#include "AI.h"
//Class constructor fxn
Player::Player(string nm){
    name = nm;
    card = 0;
}

//Accessor to set hand constants
void Player::setHand(Hand *hd){
    hand = hd;
}

//Demonstrate use of friend class fxn to set the AI's name
void Player::setName(AI &ai){
    ai.AiNm = "Lindsey";
     cout << "hey" << endl;
}

//Print hand of cards
void Player::prntHnd(){
    hand->display();
}

//Begin fxn to play a card for Player 1
unsigned char Player::playCrd(unsigned char sz){
    //Declare fxn variables
    unsigned char fce;    //Will hold input face value of card user plays
    unsigned char suit;   //Will hold the suit of the card the user plays
    //int posn = 0;
    
    //Ask player to enter the card they want to play
        cout << endl << "Enter the face value and suit of the card "
             << "you want to play (enter 'T' for 10):" << endl;
        //Convert possible lowercase input to capitals
        cin >> fce >> suit;
        suit = toupper(suit);
   if(fce == 'a' || fce == 't' || fce == 'j' || fce == 'q' || fce == 'k')
                 fce = toupper(fce);
        try
        {
            card = hand->check(fce, suit);
            return card;
        }
        catch(Hand::WrongCrd)
        {
            cout << "The card you're trying to play isn't "
                 << "in your hand!" << endl;
            playCrd(sz);
        }
}