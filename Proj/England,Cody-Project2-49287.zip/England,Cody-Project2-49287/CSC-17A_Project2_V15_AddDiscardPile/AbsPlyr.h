/* 
 * File:   AbsPlayer.h
 * Author: Cody England
 * Created on December 15, 2020, 2:41 AM
 * Purpose: AbsPlyr class specification
 */

#ifndef ABSPLAYER_H
#define ABSPLAYER_H

#include <string>
using namespace std;

#include "Hand.h"

class AbsPlyr{
    protected:
        string name;
        unsigned char deckSz;
        unsigned char card;
    public:
        virtual void setHand(Hand *)= 0;
        virtual string getName()= 0;
        virtual void prntHnd()= 0;
         
};

#endif /* ABSPLAYER_H */

