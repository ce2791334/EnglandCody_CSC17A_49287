/* 
 * File:   Player.h
 * Author: Cody England
 * Created on December 15, 2020, 12:34 AM
 * Purpose: Specifications for player class
 */

#ifndef PLAYER_H
#define PLAYER_H

#include <string>
using namespace std;

#include "AbsPlyr.h"
#include "Card.h"

class AI;

class Player : protected AbsPlyr{
    private:
        Hand *hand;
    public:
        //Constructor
        Player(string);
        ~Player(){delete []hand;}
        //Mutator fxns
        void setHand(Hand *);
        void setName(AI &);
        //Accessor fxns
        string getName(){return name;}
        void prntHnd();
        unsigned char playCrd(unsigned char);
};

#endif /* PLAYER_H */