/* 
 * File:   Player.cpp
 * Author: Cody England
 * Created on December 15, 2020, 12:34 AM
 * Purpose: Specifications for player class
 */
#include <iostream>

#include "Player.h"
#include "AI.h"

Player::Player(string nm){
    name = nm;
}

void Player::setHand(Hand *hd){
    hand = hd;
}

void Player::setName(AI &ai){
    ai.AiNm = "Lindsey";
}

void Player::prntHnd(){
    hand->display();
}