/* 
 * File:   AI.h
 * Author: Cody England
 * Created on December 15, 2020, 1:04 AM
 * Purpose: Specifications for AI class
 */

#ifndef AI_H
#define AI_H

#include <string>
using namespace std;

#include "AbsPlyr.h"
#include "Player.h"

class AI : protected AbsPlyr{
    private: 
        string AiNm;
        Hand *hand;
    public:
        AI(string);
        //Mutator
        void setHand(Hand *);
        string getName(){return AiNm;}
        void prntHnd();
        friend void Player::setName(AI &);
};

#endif /* AI_H */

