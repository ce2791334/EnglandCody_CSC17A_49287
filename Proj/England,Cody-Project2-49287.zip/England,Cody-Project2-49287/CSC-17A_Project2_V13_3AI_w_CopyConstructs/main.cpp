/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 15, 2020, 5:16 AM
 * Purpose: Object Oriented Game of Mao
 * Version 13 - Add in a copy constructor and use of a friend class fxn
 */

//System Libraries
#include <iostream>     //I/O library
#include <iomanip>      //I/O formatting library
#include <cstring>      //String library 
using namespace std;

//User Libraries
#include "Deck.h"
#include "Hand.h"
#include "Player.h"
#include "AI.h"
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    
    //Declare Variables
    static unsigned char deckSz = 52;  //Standard single deck size
    unsigned char nHnds = 4;    //Number of hands dealt (temp set to 4)
    unsigned char handSz = 12;  //Starting hand size in Mao
    string name;                //Hold player's name
    Deck<Card> deck(deckSz);         
    
    //Initialize Variables (the deck and pointer index)
    deck.shuffle();
    deck.display();
    
    cout << "Enter your name: " << endl;
    getline(cin,name);
    
    //Instantiate player classes
    Player plyr1(name);
    //Show off some constructor copying
    AI Ai1("Bob");
    AI Ai2(Ai1);
    AI Ai3(Ai1);
    cout << "The name of Computer Player 1 is: " << Ai1.getName() << endl;
    cout << "The name of Computer Player 2 is: " << Ai2.getName() << endl;
    cout << "The name of Computer Player 3 is: " << Ai3.getName() << endl;
  
    plyr1.setName(Ai1);
    cout << "Computer Player's new name: " << Ai1.getName() << endl;
    //Process inputs to outputs/map
    
    //Display hands 
    Hand hand1(deck.deal(handSz),handSz);
    plyr1.setHand(&hand1);
    cout << plyr1.getName() << "'s hand: " << endl;
    plyr1.prntHnd();
    
    Hand hand2(deck.deal(handSz),handSz);
    Ai1.setHand(&hand2);
    cout << Ai1.getName() << "'s hand: " << endl;
    Ai1.prntHnd();
    
    //Display the results 
    
    //Reallocate memory

    //Exit stage right
    return 0;
}