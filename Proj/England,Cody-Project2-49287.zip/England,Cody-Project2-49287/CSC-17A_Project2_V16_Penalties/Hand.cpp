/* 
 * File:   Hand.cpp
 * Author: Cody England
 * Created on December 13, 2020, 11:35 PM
 * Purpose: Specifications for Hand class
 */

#include <iostream>
#include <iomanip>
using namespace std;

#include "Hand.h"
//Constructor
Hand::Hand(unsigned char *crds,unsigned char hSz, unsigned char dSz){
    handSz = hSz;
    cards = new unsigned char[dSz];
    for(int i = 0; i < dSz; i++)
    {
        cards[i] = 0;
        if(i >=0 && i < hSz)
           cards[i] = crds[i]; 
    }
}
//Destructor
Hand::~Hand(){
    delete []cards;
}
//Display fxn
void Hand::display(){   
    //Declare fxn variables
    unsigned char crdHt = 2;          //height of card

    //Display top edge of cards
    for (unsigned char i = 0; i < handSz; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (unsigned char i = 0; i < handSz; i++)
    {
        Card card(cards[i]);
        //Set border of card 
        cout << "|" << setw(2);     
        //I want to show the number 10
        if (card.face() != 'T')
        cout << card.face() << card.suit() << setw(3);
        else
            cout << "10" << card.suit() << setw(3);
    }
      
    //This if statement prevents a display when there are no cards 
    //left in hand
    if (handSz > 0)
       cout << "|" << endl;
  
    //Display sides of cards
    for (int i = 0; i < crdHt; i++)
    {
        for (int j = 0; j < handSz; j++)
        cout << "|" << setw(6); 
        
        if (handSz > 0)
        cout << "|" << endl;
    }
    //Display bottom edge of cards
    for (int i = 0; i < handSz; i++)
      cout << " - - -";
    cout << endl;
}
//Check if card played is valid
unsigned char Hand::check(unsigned char fc, unsigned char st)
{
    bool crdNHnd = false;
    for(int i = 0; i < handSz; i++)
    {
        Card card(cards[i]);
        if(fc ==  card.face() && st == card.suit())
        {
            //Register that card was found in hand
            crdNHnd = true;
            return i;
        }
    }
    if(!crdNHnd)
        throw WrongCrd();
}
//Begin fxn to swap played card to back of hand for decrementation
void Hand::swap(int posn)
{   
    //Swap played card to back of hand so that it can be 
            //decremented off
    for(int i = posn; i < handSz - 1; i++)
    {
        unsigned char temp = cards[i];
        cards[i] = cards[i+1];
        cards[i+1] = temp;
    }
    //Decrement hand size
    handSz--;
    display();
}
//Accessor
Card Hand::getCrd()
{
    Card card(cards[handSz-1]);
    return card;
}
//Begin fxn to call increment handSz due to added card
void Hand::addCrd()
{
    handSz++;
}
//Begin fxn to compare AI's cards to top card of deck
unsigned char Hand::cptrTrn(unsigned char fc, unsigned char st)
{
    bool crdNHnd = false;
    for(int i = 0; i < handSz; i++)
    {
        Card card(cards[i]); 
        if(fc ==  card.face() || st == card.suit())
        {
            //Register that card was found in hand
            crdNHnd = true;
            return i;
        }
    }
    if(!crdNHnd)
        throw NoCrds();
}