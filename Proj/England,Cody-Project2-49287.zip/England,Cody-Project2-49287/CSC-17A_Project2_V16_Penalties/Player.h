/* 
 * File:   Player.h
 * Author: Cody England
 * Created on December 15, 2020, 12:34 AM
 * Purpose: Specifications for player class
 */

#ifndef PLAYER_H
#define PLAYER_H

#include <string>
using namespace std;

#include "AbsPlyr.h"
#include "Card.h"
//Announce class that Player is friends with
class AI;
//Declare Player class
class Player : protected AbsPlyr{
    private:
        string name;
        Hand *hand;
    public:
        //Constructor
        Player(string,unsigned char);
        //Mutator fxns
        void setHand(Hand *);
        void setName(AI &,string);
        //Accessor fxns
        string getName(){return name;}
        void prntHnd();
        unsigned char playCrd(unsigned char);
        unsigned char addCrd();
};

#endif /* PLAYER_H */