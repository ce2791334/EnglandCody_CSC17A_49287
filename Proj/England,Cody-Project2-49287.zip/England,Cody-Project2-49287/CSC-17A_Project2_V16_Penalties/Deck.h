/* 
 * File:   Deck.h
 * Author: Cody England
 * Created on December 14, 2020, 8:15 PM
 * Purpose: Specifications for Deck class
 */

#ifndef DECK_H
#define DECK_H

//System libraries
#include <iostream>     //I/O library
#include <cstdlib>      //Standard library for rand fxn
#include <ctime>        //Time library for randomizing of numbers
#include <iomanip>      //I/O formatting library
using namespace std;

#include "Card.h"
#include "Hand.h"
//Declare class
template <class T>
class Deck{
    private:
        unsigned char numShfl; //Standard number of deck shuffles
        unsigned char handSz;  //Starting hand size
        unsigned char *indx;   //Array to index deck
        int nDelt;             //Number of cards dealt
        unsigned char deckSz;  //Standard single deck size
        T **card;              //Card class
        unsigned char *hand;
        unsigned char cntr;    //Counter variable user for resigning discarded 
                               //cards to the bottom of the deck "discard pile"
        unsigned char fc;
        unsigned char st;
    public:
        //Exception classes
        class BadPlay
        {};
        class NoCrds      //Execute if the computer doesn't have a card to play
        {};
        //Default constructor 
        Deck(unsigned char dSz);
        ~Deck();   //Destructor
        void shuffle();
        unsigned char *deal(unsigned char);
        void display(unsigned char);
        void discard(unsigned char);
        void addCrd(unsigned char,bool);
        //void cptrTrn();
        //Accessor fxns
        unsigned char gtTpCdV();    //Get top card face value
        unsigned char gtTpCdS();    //Get top card suit
};
//Constructor
template <class T>
Deck<T>::Deck(unsigned char dSz)
{
    //Set random number seed here
    srand(static_cast<unsigned int>(time(0)));
    //Initialize Variables 
    deckSz = ((dSz >= 0)? dSz : 52);     //Make sure arrays won't be created 
                                         //with invalid ranges; 52 is standard
                                         //single deck size
    numShfl = 7;  //Standard number of deck shuffles
    handSz = 12;  //Starting hand size
    nDelt = 0;
    cntr = 0;
    //Create arrays and initialize
    indx = new unsigned char[deckSz];         //Index array
    card = new T*[deckSz];      //Allocate memory for array of 52 card 
                                    //pointers
    for(unsigned char i=0;i<deckSz;i++){
        card[i] = new T(i);      //Create each card
        indx[i] = i;
    }
    //Shuffle the deck and display first card
    shuffle();
    card[indx[cntr]] = card[indx[deckSz-1]];
    display(cntr);
    fc = card[indx[cntr]]->face();
    st = card[indx[cntr]]->suit();
}
//Destructor
template <class T>
Deck<T>::~Deck()
{
    //Reallocate Memory
    for(int i=0;i<deckSz;i++){
        delete card[i];       //Destruction of each individual card
    }
    delete []card;            //Destruction of the array of pointers
    delete []indx;
}
//Begin fxn to shuffle deck
template <class T>
void Deck<T>::shuffle()
{
    //For loop that iterates through the number of deck shuffles
    for(int i = 1; i <= numShfl; i++){
        //For loop to reindex each card in the deck
        for(int j = 0; j < deckSz; j++){
            int temp=rand()%deckSz;
            int card=indx[j];
            indx[j]=indx[temp];
            indx[temp]=card;
        }
    }
   /* for(unsigned char crd=0;crd<deckSz;crd++){
        cout<<static_cast<int>(indx[crd])<<" "<<card[indx[crd]]->face()             /////display deck remove later
                <<card[indx[crd]]->suit()<<" "<<endl;
    }*/
}
//Begin fxn to deal hands
template <class T>
unsigned char *Deck<T>::deal(unsigned char sz)
{
    //Declare variables
    unsigned char handSz((sz > 0)?sz:12);   //Protect range of arrays, 
                                  //standard hand size for Mao is 12
    //Create the hand
    hand = new unsigned char[deckSz];
    //Only two players in this game so condition in this current capacity 
    //will never be fulfilled unless playing with more people and decks
    if(handSz>deckSz-nDelt){
        shuffle();
        nDelt = 0;
    }
    //For loop to assign each card in hand from every other card in deck 
    for(int i=0;i<handSz;i++){
        hand[i]=indx[nDelt++];
    }
    for(int j = handSz; j < deckSz; j++)
        hand[j] = 0;
    //Return the dealt hand
    return hand;
}
//Begin fxn to display top card of discard pile and deck
template <class T>
void Deck<T>::display(unsigned char posn){    
    //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    
    //Display "deck"
      cout << " X X X   - - - " << endl; //Top edge
    //Loop to display centers of top of next card in deck
    //and the face of the card shown
    for (int i = 0; i < crdHt + 1; i++)
    {
        for(int j = 0; j < crdHt * 2; j++)
        cout << "X ";  
        cout << "|" << setw(2);
        if(i == 0)
        {
            //Make sure to display '10' rather than 'T'
            if (card[indx[posn]]->face() != 'T')
            {
                cout << card[indx[posn]]->face() 
                     <<card[indx[posn]]->suit()<< setw(3);
            }
            else
                cout << "10" << card[indx[posn]]->suit() << setw(3);
            
            cout << "|" << endl;
        }
        else{
            cout << setw(6) << "|" << endl;
        }
    }
      cout << " X X X   - - - " << endl;
}
//Begin fxn to check if a card was played that matches suit or face value
template <class T>
void Deck<T>::discard(unsigned char cP)
{   
    cout << card[indx[cP]]->face() << card[indx[cP]]->suit() << endl << endl;
    if(card[indx[cP]]->face() == card[indx[cntr]]->face() ||
             card[indx[cP]]->suit() == card[indx[cntr]]->suit()) //fail happening here
    {
        card[indx[cntr]] = card[indx[cP]];
    }  
    else
        throw BadPlay();
    
    fc = card[indx[cntr]]->face();
    st = card[indx[cntr]]->suit();
    //Output new top card
    display(cntr);
    //Increment counter variable
    cntr++;
    if(cntr == deckSz)
        cntr = 0;
}
//Begin fxn to add on a card to a hand
template<class T>
void Deck<T>::addCrd(unsigned char hndSz, bool cond)
{
   hand[handSz] = indx[nDelt++];
   if(nDelt == deckSz)
       nDelt = 0;
   //This condition will be true if the AI gained a card so that the top card
   //of the discard pile will be redisplayed for user to see
   if(cond)
       display(cntr);
}

//Begin fxn to get top card face value
template <class T>
unsigned char Deck<T>::gtTpCdV()
{
     return fc;
 } 
 //Begin fxn to get top card suit
template<class T>
unsigned char Deck<T>::gtTpCdS()
 { 
     return st;
 }
/*/Begin fxn to compare AI's cards to top card of deck
template<class T>
void Deck<T>::cptrTrn(unsigned char hdSz)
{
    bool crdNHnd = false;
    for(int i = 0; i < hdSz; i++)
    {
        Card card(cards[i]);
        if(fc ==  card.face() && st == card.suit())
        {
            //Register that card was found in hand
            crdNHnd = true;
            cout << static_cast<int>(cards[i]) << endl;     //Remove at end
            return i;
        }
    }
    if(!crdNHnd)
        throw NoCrds();
}*/

#endif /* DECK_H */