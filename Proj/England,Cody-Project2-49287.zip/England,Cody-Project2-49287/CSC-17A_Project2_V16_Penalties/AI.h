/* 
 * File:   AI.h
 * Author: Cody England
 * Created on December 15, 2020, 1:04 AM
 * Purpose: Specifications for AI class
 */

#ifndef AI_H
#define AI_H

#include <string>
using namespace std;

#include "AbsPlyr.h"
#include "Player.h"
//Declare AI class
class AI : protected AbsPlyr{
    private: 
        string AiNm;
        Hand *hand;
    public:
        //Constructor
        AI(string,unsigned char);
        //Copy constructor
        AI(const AI &);
        //Mutator
        void setHand(Hand *);
        string getName(){return AiNm;}
        void prntHnd();
        friend void Player::setName(AI &,string);
        unsigned char playCrd(unsigned char,unsigned char);
        //Getter fxn
        unsigned char addCrd();
        const AI operator=(const AI &);
};

#endif /* AI_H */

