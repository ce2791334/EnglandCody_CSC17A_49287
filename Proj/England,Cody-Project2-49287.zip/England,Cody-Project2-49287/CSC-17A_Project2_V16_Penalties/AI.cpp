/* 
 * File:   AI.cpp
 * Author: Cody England
 * Created on December 15, 2020, 1:04 AM
 * Purpose: Specifications for AI class
 */

#include <iostream>
#include <string>
using namespace std;
#include "AI.h"

//Constructor
AI::AI(string aNm,unsigned char hdSz){
    AiNm = aNm;
    handSz = hdSz;
}
//Destructor
AI::AI(const AI &ai){
    AiNm = ai.AiNm;
}
//Mutator
void AI::setHand(Hand *hd){
    hand = hd;
}
//Print the AI's current hand of cards
void AI::prntHnd(){
    hand->display();
}
//Play a card level 1
unsigned char AI::playCrd(unsigned char fc,unsigned char st)
{
    unsigned char crd;
    crd = hand->cptrTrn(fc,st);
    return crd;
}
//Getter fxn to add card to AI's hand
unsigned char AI::addCrd()
{
    //Increment hand size
    hand->addCrd();
    handSz++;
    return handSz;            
}
//Overloaded = operator
const AI AI::operator=(const AI &right)
{
    if(this != &right)
    {
        AiNm = right.AiNm;
        hand = right.hand;      
    }
}