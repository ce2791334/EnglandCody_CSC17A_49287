/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 12, 2020, 8:38 PM
 * Purpose: Object Oriented Game of Mao
 * Version 2 - Move the card to a class
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Card.h"
//Global Constants

//Function Prototypes
char suit(int);
char face(int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    const char DECKSZ = 52;
    //Declare Variables
    
    //Initialize Variables
    for(int i=0;i<DECKSZ;i++){
        Card card(i);
        cout<<i+1<<" "<<card.face()<<card.suit()<<" "<<endl;
    }
    //Process inputs to outputs/map
    
    //Display the results

    //Clean up and exit stage right
    return 0;
}
