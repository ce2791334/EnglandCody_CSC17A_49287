var searchData=
[
  ['name_114',['name',['../class_abs_plyr.html#ad83cb6faf3a3a46ce010ac7325bfb4a4',1,'AbsPlyr::name()'],['../class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player::name()']]],
  ['ndelt_115',['nDelt',['../class_deck.html#ab3a94295f1deedcba35965475ef32c6c',1,'Deck']]],
  ['numshfl_116',['numShfl',['../class_deck.html#a598c13e4eb678084a8be4201e8f9271b',1,'Deck']]]
];
