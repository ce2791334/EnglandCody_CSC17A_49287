var searchData=
[
  ['badplay_58',['BadPlay',['../class_deck_1_1_bad_play.html',1,'Deck']]]
];
