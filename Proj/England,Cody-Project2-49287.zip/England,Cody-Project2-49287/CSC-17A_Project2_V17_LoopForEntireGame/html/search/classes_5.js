var searchData=
[
  ['nocrds_62',['NoCrds',['../class_hand_1_1_no_crds.html',1,'Hand::NoCrds'],['../class_deck_1_1_no_crds.html',1,'Deck&lt; T &gt;::NoCrds']]]
];
