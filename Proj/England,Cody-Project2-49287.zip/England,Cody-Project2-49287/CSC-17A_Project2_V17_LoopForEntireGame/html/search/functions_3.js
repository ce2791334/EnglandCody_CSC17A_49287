var searchData=
[
  ['face_85',['face',['../class_card.html#aa171c6e75356098c804fc3986cf5a33d',1,'Card']]]
];
