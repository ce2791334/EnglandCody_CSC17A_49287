var searchData=
[
  ['wrongcrd_53',['WrongCrd',['../class_hand_1_1_wrong_crd.html',1,'Hand']]]
];
