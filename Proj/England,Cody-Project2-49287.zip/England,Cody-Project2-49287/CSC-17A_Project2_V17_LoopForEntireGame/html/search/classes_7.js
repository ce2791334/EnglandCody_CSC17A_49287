var searchData=
[
  ['wrongcrd_64',['WrongCrd',['../class_hand_1_1_wrong_crd.html',1,'Hand']]]
];
