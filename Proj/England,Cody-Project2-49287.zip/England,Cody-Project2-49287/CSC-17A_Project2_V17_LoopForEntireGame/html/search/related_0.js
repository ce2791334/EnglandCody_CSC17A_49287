var searchData=
[
  ['setname_118',['setName',['../class_a_i.html#a924f46523b1cc8ffd5a76d860ae57948',1,'AI']]]
];
