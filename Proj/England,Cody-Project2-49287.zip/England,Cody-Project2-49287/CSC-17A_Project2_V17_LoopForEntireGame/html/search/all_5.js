var searchData=
[
  ['getcrd_24',['getCrd',['../class_hand.html#a63bfe5a9511fbc84bc02a775e52eb1e6',1,'Hand']]],
  ['getname_25',['getName',['../class_abs_plyr.html#aed4c214c8d8b601897ddd052300b759b',1,'AbsPlyr::getName()'],['../class_a_i.html#aa3c42dd0737e494130f9c300f9963618',1,'AI::getName()'],['../class_player.html#af9a6045fa96f736664c4eab4caa5e8e5',1,'Player::getName()']]],
  ['gtcrdnm_26',['gtCrdNm',['../class_card.html#acd20113713d91024d698e0715950a3ca',1,'Card']]],
  ['gttpcds_27',['gtTpCdS',['../class_deck.html#a99587fce598a635912928f05527a0154',1,'Deck']]],
  ['gttpcdv_28',['gtTpCdV',['../class_deck.html#a79e76dd9312822a581e0ab0a96758fe0',1,'Deck']]]
];
