/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 18, 2020, 3:05 AM
 * Purpose: Object Oriented Game of Mao
 * Version 17 - Loop for entire game and add Mao rules 
 */

//System Libraries
#include <iostream>     //I/O library
#include <iomanip>      //I/O formatting library
#include <cstring>      //String library 
using namespace std;

//User Libraries
#include "Deck.h"
#include "Hand.h"
#include "Player.h"
#include "AI.h"
#include "Card.h"
//Global Constants

//Function Prototypes
//void startGm(Player,AI,unsigned char);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    //Set constants
    //Declare Variables
    static unsigned char deckSz = 52;  //Standard single deck size
    unsigned char nHnds = 4;    //Number of hands dealt (temp set to 4)
    unsigned char handSz = 12;  //Starting hand size in Mao
    string name;                //Hold player's name
    bool ifBthPd = true;        //Determines whether both players played a 
                                //card or not
    bool cond = false;          //Holds true or false depending on which 
                                //player's turn it is to determine whether or 
                                //not to redisplay the last played card
    unsigned char fc = 0;       //Will hold face value of top card on table
    unsigned char st = 0;       //Will hold suit of top card on table
    unsigned char card1, card2; //Will hold the return position of cards played
   //Initialize Variables (the deck and pointer index)    
    cout << "Enter your name: " << endl;
    getline(cin,name);
    
    //Instantiate player classes
    Player plyr1(name,handSz);
    AI Ai1("Bob",handSz);   
    //Ask user for computer player's name
    //cout << "Enter a name for your computer opponent :" << endl;
    //getline(cin,name);
    //plyr1.setName(Ai1,name);
    //Show off some constructor copying
    AI Ai2(Ai1);
    AI Ai3(Ai1);
    
     //Instantiate Deck 
    Deck<Card> deck(deckSz); 
    //Process inputs to outputs/map
    
    //Instantiate hands and display
    Hand hand1(deck.deal(handSz),handSz,deckSz);
    plyr1.setHand(&hand1);
    cout << plyr1.getName() << "'s hand: " << endl;
    plyr1.prntHnd();
    
    /*Hand hand2(deck.deal(handSz),handSz, deckSz);
    Ai1.setHand(&hand2);
    cout << Ai1.getName() << "'s hand: " << endl;
    Ai1.prntHnd();*/
    //Play a cards
    do
    {
    try
    {
     //User plays a card
     card1 = plyr1.playCrd(handSz);
     cout << plyr1.getName() << " played: ";
     //If they played a good card then they can place on the top 
     //of the discard pile
     deck.discard(card1,ifBthPd);
     //Swap played card to back of hand to decrement hand size
     handSz = hand1.swap(card1);
     ifBthPd = true;
    }
    catch(Deck<Card>::BadPlay)
    {
        //Penalization message
        cout << "Penalty for not playing a card that matches suit "
             << "or face value." << endl;
        //If a bad card was played then player gains 1 card
        handSz = plyr1.addCrd();
        deck.addCrd(handSz, cond);
        handSz++;
        //Reprint hand
        plyr1.prntHnd();
        ifBthPd = false;
    }   
    }while(handSz > 0);
    
    return 0;
    try
    {
        //Retrieve top card value and suit
        fc = deck.gtTpCdV();
        st = deck.gtTpCdS();
        //AI plays a card 
        card2 = Ai1.playCrd(fc,st);
        cout << Ai1.getName() << " played: ";
        //If they can play a card then they put on top of discard pile
        deck.discard(card2,ifBthPd);
        //Swap played card to back of hand to decrement hand size
        //hand2.swap(card2);
        ifBthPd = true;
    }
    catch(Hand::NoCrds)
    {
        //Penalization message
        cout << Ai1.getName() << " was penalized because they didn't have "
             << "any cards to play." << endl;
        //If a bad card was played then AI gains 1 card
        handSz = Ai1.addCrd();
        deck.addCrd(handSz, cond);
        //Reprint hand                  //remove at end
        Ai1.prntHnd();
        ifBthPd = false;
    }
    catch(Deck<Card>::BadPlay)
    {
        //Penalization message
        cout << "Penalty for not playing a card that matches suit "
             << "or face value." << endl;
        Ai1.prntHnd();
        ifBthPd = false;
    }
    //Reallocate memory

    //Exit stage right
    return 0;
}


 /*


/
//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
//Declare variables or constants here
//7 characters or less
    const unsigned char DECK = 52;
    const unsigned char DEALSZ = 12; //This variable could be removed
                                     //but leaving it here allows for easy
                                     //adjustment of starting hand size if
                                     //desired
    fstream P1File;                  //File to hold Player 1's hand
    fstream AIFile;                  //File to hold AI player's hand
    unsigned char key;               //Just used to start the game
    //Start game
    cout << "Welcome to Mao! \nWarning this game is not for the faint "
         << "of heart as you must \nfigure out the rules as you go."
         << "When you play a card, you may \nbe presented with a menu "
         << "of numbers, each of which corresponds to \na particular "
         << "condition of the card you played. Choose wisely!\n"
         << "Hit any key to continue:\n";




//Begin fxn to play a card
int playCrd(fstream &file, Cards *hand, Cards *dscrd, Cards *deck,
             const unsigned char turn)
{
    //Declare fxn variables
    string play;    //Will hold input value of card user plays
    bool valid = true;  //Boolean value to check that card played is valid
    unsigned char posn; //Will hold the position of the card played
    unsigned char goodCrd; //This variable will hold either 1 or 2 depending
                           //on whether play followed all rules
    //Enter do while loop to ask player for a card as long as they enter an
    //invalid card
    do{
        //Ask player to enter the card they want to play
        cout << endl << "Enter the face value and suit of the card "
             << "you want to play (enter 'T' for 10):" << endl;
        cin >> play;
     
        //Loop to check that card played is one from hand
        for(unsigned char i = 0; i < hand->hand->hdSz; i++)
        {
           //If card isn't in the player's hand
           if(hand->hand[i].card != play) 
               valid = false;
           else
           {
               posn = i;
               valid = true;
               break;
           }
        }
        if(!valid)
        {
            cout << "The card you're trying to play isn't in your hand!"
                 << endl;
        }
    }while(!valid);
    //Checck that play followed rules. If not then penalize with 
    //additional card
    goodCrd = rules(hand->hand[posn].card, dscrd, turn);
    //If 2 then ggod play and proceed normally
    if(goodCrd == '2') //Execute a good play procedure
        goodPly(hand, dscrd, turn, posn);
    else //Execute a bad play procedure
        badPly(hand, deck, posn);
    //Write the new hand to file
    wrtBin(file, hand);
    //Conditional return value of good or bad play
    if(goodCrd == '2')
        return 0;
    else return 1;
}

//Begin fxn to display the card played by the AI
int AIplay(fstream &file, Cards *AI, Cards *dscrd, Cards *deck,
            const unsigned char turn)
{
    //Declare fxn variables
    bool check = false;         //Check if AI has a playable card
    unsigned int indx = 0;     //index to check AI hand for playable card
    //Enter while loop to only play valid card for AI if possible
    while( indx < static_cast<int>(AI->hand->hdSz))
    {
        if(AI->hand[indx].card[0] == dscrd->hand[turn - 1].card[0] 
           || AI->hand[indx].card[1] == dscrd->hand[turn - 1].card[1])
        {
            check = true;
            break;
        }
        indx++;
    }
    //If valid card found then execute a good play procedure
    if(check) 
    {
        cout << "Computer played..." << endl;
        goodPly(AI, dscrd, turn, indx);
    }
    else //Execute a bad play procedure
    {
        badPly(AI, deck, indx);
        cout << "Computer was penalized for not matching "
             << "suit or face value\n";
    }
    //Write the new hand to file
    wrtBin(file, AI);
    //Conditional return value of good or bad play
    if(check)
        return 0;
    else return 1;
}

//Begin swap fxn to adjust hand for card plays
void swap(Cards *hand, unsigned char posn)
{
    for(unsigned char i = posn; i < hand->hand->hdSz; i++)
    {
        string temp = hand->hand[i].card;
        hand->hand[i].card = hand->hand[i + 1].card;
        hand->hand[i + 1].card = temp;
    }
}

//Begin fxn to execute each turn in the game
void gmePlay(fstream &P1File, fstream &AIFile, 
             Cards *deck, Cards *P1, Cards *AI, Cards *dscrd)
{
    //Declare fxn variables
    unsigned char turn = 1;          //Counter representing each turn
    int testVal;                     //This will be use to test if play 
                                     //was good or bad
    //Print initial hands
    prntCds(P1File, P1);
    //Enter do while loop to continue turns until 1 player plays all 
    //cards.  Increment turn counter after each play 
    //(so technically counter represents a half turn)
    do{
        //Play a card
        testVal = playCrd(P1File, P1, dscrd, deck, turn);
        //Test results of Player 1's turn
        tests(deck,testVal,turn);
        //AI's turn
        testVal = AIplay(AIFile, AI, dscrd, deck, turn);
         //Test results of AI's turn
        tests(deck,testVal,turn);
        //Print hand after turn
        prntCds(P1File, P1);
    }while(P1->hand->hdSz > 0 && AI->hand->hdSz > 0);
    if(P1->hand->hdSz == '0')
        cout << "Congratulations, you won!" << endl;
    else
        cout << "Too bad, AI wins :(" << endl;
}

 //Begin fxn to test if game rules are followed during a play
unsigned char rules(string crdPlyd, Cards *dscrd, unsigned char turn)
{
    unsigned char choice; //This will be '2' if all rules are followed 
                       //and '1' if any rule is broken
    //Independent if statements to check each rule of play
    //Rule 1: Cards played must be of either same suit or face value
    if(crdPlyd[0] != dscrd->hand[turn - 1].card[0] && crdPlyd[1] != 
       dscrd->hand[turn - 1].card[1])
    {
        cout << "You were penalized for not matching "
             << "suit or face value\n";
        choice = '1';
        return choice;
    }
    //Rule 2: if an ace is played then '1' must be entered
    if(crdPlyd[0] == 'A')
    {
        choice = chceMnu();
        if(choice != '1')
        {
            cout << "You were penalized for not choosing '1'\n";
            choice = '1';
            return choice;
        }
    }
    //Rule 3: If the suit of top card on discard pile is changed then
    //a '2' must be entered
    if(crdPlyd[0] == dscrd->hand[turn - 1].card[0])
    {
        choice = chceMnu();
        if(choice != '2')
        {
            cout << "You were penalized for not choosing '2'\n";
            choice = '1';
            return choice;
        }
    }
    //Rule 4: If a short run occurs (any 2 values in a row in 
    //increasing order) than a '3' must be entered
    if(turn >= '2')
    if(dscrd->hand[turn - 1].card[0] == dscrd->hand[turn - 2].card[0])
    {
        choice = chceMnu();
        if(choice != '3')
        {
            cout << "You were penalized for not choosing '3'\n";
            choice = '1';
            return choice;
        }
    }  
        //Fulfilled all rules!
        choice = '2';
        return choice;
}


//Begin fxn that executes if card played doesn't follow rules
void badPly(Cards *hand, Cards *deck, unsigned char posn)
{ 
    //If bad play then penalize by adding a card to player's hand
    //Give card from bottom of deck. Not realistic but 
    //simplest implementation
    hand->hand[hand->hand->hdSz].card = deck->hand[deck->hand->hdSz].card;
    //Increment hand size to account for penalization card 
    //which means decrementing the deck
    hand->hand->hdSz++;
    deck->hand->hdSz--;
}

//Begin fxn to execute tests in between turns
void tests(Cards *deck,const int val,unsigned char &turn)
{
    //Control the turn counter to control top card of discard pile 
    //that's compared to
    if(val == 0)
    turn++;
    //Check if deck is empty b/c then discard pile will be flipped over   
    if(static_cast<int>(deck->hand->hdSz) == 0)
        flpDcds;
}



//Begin fxn to display menu for Player to choose a number 
//to satisfy condition
unsigned char chceMnu()
{
    //Declare fxn variables
    unsigned char choice;
    //Ask Player to choose a number
    cout << "Enter 1, 2, or 3:" << endl;
    cin >> choice;
    
    return choice;
}*/