/* 
 * File:   Deck.cpp
 * Author: Cody England
 * Created on December 14, 2020, 8:15 PM
 * Purpose: Specifications for Deck class
 */

//System libraries
#include <iostream>     //I/O library
#include <cstdlib>      //Standard library for rand fxn
#include <ctime>        //Time library for randomizing of numbers
using namespace std;

//User libraries
#include "Deck.h"

Deck::Deck(unsigned char dSz)
{
    //Set random number seed here
    srand(static_cast<unsigned int>(time(0)));
    //Initialize Variables 
    deckSz = ((dSz >= 0)? dSz : 52);     //Make sure arrays won't be created 
                                         //with invalid ranges; 52 is standard
                                         //single deck size
    numShfl = 7;  //Standard number of deck shuffles
    handSz = 12;  //Starting hand size
    nDelt = 0;
    //Create arrays and initialize
    indx = new int[deckSz];         //Index array
    card = new Card *[deckSz];      //Allocate memory for array of 52 card 
                                    //pointers
    for(int i=0;i<deckSz;i++){
        card[i] = new Card(i);      //Create each card
        indx[i] = i;
    }
}

Deck::~Deck()
{
    //Reallocate Memory
    for(int i=0;i<deckSz;i++){
        delete card[i];       //Destruction of each individual card
    }
    delete []card;            //Destruction of the array of pointers
    delete []indx;
}

void Deck::shuffle()
{
    //For loop that iterates through the number of deck shuffles
    for(int i = 1; i <= numShfl; i++){
        //For loop to reindex each card in the deck
        for(int j = 0; j < deckSz; j++){
            int temp=rand()%deckSz;
            int card=indx[j];
            indx[j]=indx[temp];
            indx[temp]=card;
        }
    }
}

unsigned char *Deck::deal(unsigned char sz)
{
    //Declare variables
    unsigned char handSz((sz > 0)?sz:12);   //Protect range of arrays, 
                                  //standard hand size for Mao is 12
    //Create the hand
    unsigned char *hand = new unsigned char[handSz];
    //Only two players in this game so condition in this current capacity 
    //will never be fulfilled unless playing with more people and decks
    if(handSz>deckSz-nDelt){
        shuffle();
        nDelt = 0;
    }
    //For loop to assign each card in hand from every other card in deck 
    for(int i=0;i<handSz;i++){
        hand[i]=indx[nDelt++];
    }
    //Return the dealt hand
    return hand;
}

void Deck::display(){
    for(int i=0;i<deckSz;i++){
        cout<<static_cast<int>(indx[i])<<" "<<card[indx[i]]->face()
            <<card[indx[i]]->suit()<<" "<<endl;
    }
}