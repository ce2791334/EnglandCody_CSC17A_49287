/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 14, 2020, 11:35 PM
 * Purpose: Object Oriented Game of Mao
 * Version 7 - Move hands to their own class
 */

//System Libraries
#include <iostream>     //I/O library
#include <iomanip>      //I/O formatting library

using namespace std;

//User Libraries
#include "Deck.h"
#include "Hand.h"
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    
    //Declare Variables
    unsigned char deckSz = 52;  //Standard single deck size
    unsigned char nHnds = 4; //Number of hands dealt (temp set to 4)
    unsigned char handSz = 12;  //Starting hand size in Mao
    Deck deck(deckSz);         
    
    //Initialize Variables (the deck and pointer index)
    deck.display();
    
    cout << "\n\n\n\n";
    //Process inputs to outputs/map
    
    //Display hands 
    for(int j=1;j<=nHnds;j++){
        cout<<endl<<"Hand "<<j<<" contains the following cards"<<endl;
        Hand hand(deck.deal(handSz),handSz);
        hand.display();
    }
    
    //Display the results 
    
    //Reallocate memory
    
    //Exit stage right
    return 0;
}


