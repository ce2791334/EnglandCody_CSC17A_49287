/* 
 * File:   Hand.cpp
 * Author: Cody England
 * Created on December 13, 2020, 11:35 PM
 * Purpose: Specifications for Hand class
 */

#include "Hand.h"
#include "Card.h"
#include <iostream>
using namespace std;

Hand::Hand(unsigned char *crd,unsigned char hSz){
    cards = crd; 
    handSz = hSz;
}

Hand::~Hand(){
    delete []cards;
}

void Hand::display(){   
    for(int i=0;i<handSz;i++){
        Card card(cards[i]);
        cout<<static_cast<int>(cards[i])<<" "<<card.face()<<card.suit()<<" "
            <<endl;
    }
}
