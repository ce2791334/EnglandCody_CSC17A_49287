/* 
 * File:   Deck.h
 * Author: Cody England
 * Created on December 14, 2020, 8:15 PM
 * Purpose: Specifications for Deck class
 */

#ifndef DECK_H
#define DECK_H

#include "Card.h"

class Deck{
    private:
    unsigned char deckSz;  //Standard single deck size
    unsigned char numShfl; //Standard number of deck shuffles
    unsigned char handSz;  //Starting hand size
    int nDelt;             //Number of cards dealt
    Card **card;           //Card class
    int *indx;             //Array to index deck
    
    public:
        //Default constructor 
        Deck(unsigned char dSz);
        ~Deck();   //Destructor
        void shuffle();
        unsigned char *deal(unsigned char);
        void display();
};


#endif /* DECK_H */

