/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 14, 2020, 4:30 PM
 * Purpose: Object Oriented Game of Mao
 * Version 4 - Shuffle deck with index
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Card.h"
//Global Constants

//Function Prototypes
void shuffle(int *,const unsigned char,const unsigned char);
void destroy(Card **,int *,const unsigned char);

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    const unsigned char DECKSZ = 52;  //Standard single deck size
    const unsigned char numShfl = 7;  //Standard number of deck shuffles
    //Declare Variables
    Card **deck;    //Card deck class
    
    //Initialize Variables (the deck and pointer index)
    int *indx = new int[DECKSZ];    //Index array
    deck = new Card *[DECKSZ];      //Allocate memory for array of 52 card 
                                    //pointers
    for(int i=0;i<DECKSZ;i++){
        deck[i] = new Card(i);      //Create each card
        indx[i] = i;
    }
    //Process inputs to outputs/map
    shuffle(indx,DECKSZ,numShfl);
    for(int i=0;i<DECKSZ;i++){
        cout<<indx[i] + 1<<" "<<deck[indx[i]]->face()<<deck[indx[i]]->suit()
            << " " << endl;
    }
    
    //Display the results
    
    //Reallocate memory
    destroy(deck, indx, DECKSZ);
    
    //Exit stage right
    return 0;
}

//Begin shuffle fxn
void shuffle(int *indx,const unsigned char n,const unsigned char nShf){
    for(int i = 1; i <= nShf; i++){
        for(int j = 0; j < n; j++){
            int temp=rand()%n;
            int card=indx[j];
            indx[j]=indx[temp];
            indx[temp]=card;
        }
    }
}

//Begin destroy fxn to reallocate memory
void destroy(Card **deck, int *indx, const unsigned char sz)
{
    //Reallocate Memory
    for(int i=0;i<sz;i++){
        delete deck[i];       //Destruction of each individual card
    }
    delete []deck;            //Destruction of the array of pointers
    delete []indx;

}
