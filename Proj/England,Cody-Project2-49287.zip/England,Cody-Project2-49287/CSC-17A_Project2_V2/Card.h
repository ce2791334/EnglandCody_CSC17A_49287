/* 
 * File:   Card.h
 * Author: Cody England
 * Created on December 12, 2020, 8:39 PM
 * Purpose: Specifications for Card class
 */

#ifndef CARD_H
#define CARD_H

class Card{
    private:
        unsigned char cardNum;
    public: 
        Card(unsigned char);
        char face();
        char suit();
        char gtCrdNm(){return cardNum;};
};

#endif /* CARD_H */

