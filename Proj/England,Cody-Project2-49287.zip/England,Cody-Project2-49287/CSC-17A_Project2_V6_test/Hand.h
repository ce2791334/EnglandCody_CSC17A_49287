#ifndef HAND_H
#define HAND_H

class Hand{
    private:
        unsigned char nCards;
        unsigned char *cards;
    public:
        Hand(unsigned char *,unsigned char);
        ~Hand();
        void display();
};

#endif /* HAND_H */
