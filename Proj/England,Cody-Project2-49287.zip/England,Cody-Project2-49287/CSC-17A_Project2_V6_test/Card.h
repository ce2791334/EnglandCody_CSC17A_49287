/* 
 * File:   Card.h
 * Author: Cody England
 * Created on December 12, 2020, 8:39 PM
 * Purpose: Specifications for Card class
 */

#ifndef CARD_H
#define CARD_H

class Card{
    private:
        unsigned char crdNum;
    public:
        Card(unsigned char);
        char suit();
        char face();
        char value();
        char getCrdNm(){return crdNum;}
};


#endif /* CARD_H */
