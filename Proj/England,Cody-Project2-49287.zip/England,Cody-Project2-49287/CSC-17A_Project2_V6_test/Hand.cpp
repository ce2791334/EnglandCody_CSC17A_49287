/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Hand.h"
#include "Card.h"
#include <iostream>
using namespace std;

Hand::Hand(unsigned char *crd,unsigned char n){
    cards=crd;
    nCards=n;
}
        
Hand::~Hand(){
    delete []cards;
}
        
void Hand::display(){
    for(char crd=0;crd<nCards;crd++){
        Card card(cards[crd]);
        cout<<static_cast<int>(cards[crd])<<" "<<card.face()
                <<card.suit()<<" "
                <<static_cast<int>(card.value())<<endl;
    }
}

