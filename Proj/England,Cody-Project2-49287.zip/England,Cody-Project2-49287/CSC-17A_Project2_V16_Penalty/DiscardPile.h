/* 
 * File:   DiscardPile.h
 * Author: Cody England
 * Created on December 18, 2020, 3:12 AM
 * Purpose: Specifications for DiscardPile class
 */

#ifndef DISCARDPILE_H
#define DISCARDPILE_H

#include <iomanip>
using namespace std;
#include "Hand.h"

template<class T>
class DiscardPile{
    private:
        unsigned char deckSz;
        unsigned char pileSz;
        T **card;              //Card class
    public:
        //Constructor
        DiscardPile(unsigned char);
        //Destructor
        ~DiscardPile();
        //Place card on discard pile after play
        void discard(Hand );
        //Display top card of discard pile
        void dsplay();
};

template<class T>
DiscardPile<T>::DiscardPile(unsigned char dSz)
{
    deckSz = dSz;
    pileSz = 0;
    //Allocate memory for array of 52 cards which is the max that could
    //be in the discard pile
    card = new T*[deckSz]; 
     for(unsigned char i=0;i<deckSz;i++){
        card[i] = new T(i);      //Create each card
    }                           
}

template<class T>
DiscardPile<T>::~DiscardPile()
{
     for(unsigned char i=0;i<deckSz;i++){
        delete card[i];
    }
     delete []card;
}

template<class T>
void DiscardPile<T>::discard(Hand hnd)
{
    card[pileSz] = hnd.getCrd();
    dsplay();
    pileSz++;
}

template <class T>
void DiscardPile<T>::dsplay()
{
    //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    
    //Display "deck"
      cout << " X X X   - - - " << endl; //Top edge
    //Loop to display centers of top of next card in deck
    //and the face of the card shown
    for (int i = 0; i < crdHt + 1; i++)
    {
        for(int j = 0; j < crdHt * 2; j++)
        cout << "X ";  
        cout << "|" << setw(2);
        if(i == 0)
        {
            //Make sure to display '10' rather than 'T'
            if (card[pileSz]->face() != 'T')
            {
                cout << card[pileSz]->face() 
                     <<card[pileSz]->suit()<< setw(3);
            }
            else
                cout << "10" << card[pileSz]->suit() << setw(3);
            
            cout << "|" << endl;
        }
        else{
            cout << setw(6) << "|" << endl;
        }
    }
      cout << " X X X   - - - " << endl;
}
#endif /* DISCARDPILE_H */

