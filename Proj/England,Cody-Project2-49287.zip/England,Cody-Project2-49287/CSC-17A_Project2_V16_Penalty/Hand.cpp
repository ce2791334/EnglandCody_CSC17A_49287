/* 
 * File:   Hand.cpp
 * Author: Cody England
 * Created on December 13, 2020, 11:35 PM
 * Purpose: Specifications for Hand class
 */

#include <iostream>
#include <iomanip>
using namespace std;

#include "Hand.h"

Hand::Hand(unsigned char *crds,unsigned char hSz){
    cards = crds; 
    handSz = hSz;
}

Hand::~Hand(){
    delete []cards;
}

void Hand::display(){   
    //Declare fxn variables
    unsigned char crdHt = 2;          //height of card

    //Display top edge of cards
    for (unsigned char i = 0; i < handSz; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (unsigned char i = 0; i < handSz; i++)
    {
        Card card(cards[i]);
        //Set border of card 
        cout << "|" << setw(2);     
        //I want to show the number 10
        if (card.face() != 'T')
        cout << card.face() << card.suit() << setw(3);
        else
            cout << "10" << card.suit() << setw(3);
    }
      
    //This if statement prevents a display when there are no cards 
    //left in hand
    if (handSz > 0)
       cout << "|" << endl;
  
    //Display sides of cards
    for (int i = 0; i < crdHt; i++)
    {
        for (int j = 0; j < handSz; j++)
        cout << "|" << setw(6); 
        
        if (handSz > 0)
        cout << "|" << endl;
    }
    //Display bottom edge of cards
    for (int i = 0; i < handSz; i++)
      cout << " - - -";
    cout << endl;
}

char Hand::check(unsigned char fc, unsigned char st)
{
    bool crdNHnd = false;
    for(int i = 0; i < handSz; i++)
    {
        Card card(cards[i]);
        if(fc ==  card.face() && st == card.suit())
        {
            
            //Register that card was found in hand
            crdNHnd = true;
            //Swap played card to back of hand so that it can be 
            //decremented off
            swap(i);
        }
    }
    if(!crdNHnd)
        throw BadPlay();
}

void Hand::swap(int posn)
{   
    //Loop to swap index values of cards in hand    
    for(int i = posn; i < handSz - 1; i++)
    {
        unsigned char temp = cards[i];
        cards[i] = cards[i+1];
        cards[i+1] = temp;
    }
    //Decrement hand size
    handSz--;
}

Card Hand::getCrd()
{
    Card card(cards[handSz-1]);
    return card;
}