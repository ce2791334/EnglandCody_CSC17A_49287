/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 14, 2020, 8:08 PM
 * Purpose: Object Oriented Game of Mao
 * Version 6 - Create Deck class and move related items to it; Clean 
 * up main
 */

//System Libraries
#include <iostream>     //I/O library
#include <iomanip>      //I/O formatting library

using namespace std;

//User Libraries
#include "Deck.h"
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    
    //Declare Variables
    unsigned char deckSz = 52; //Standard single deck size
    unsigned char handSz = 12; //Starting hand size in Mao
    unsigned char nHnds = 4; //Number of hands dealt (temp set to 4)
    Deck deck(deckSz);
    
    //Initialize Variables (the deck and pointer index)
    deck.shuffle();
    
    //Process inputs to outputs/map
    int *hand;
    
    //Display hands 
    for(int j=0;j<=nHnds;j++){
        hand=deck.deal(handSz);
        cout<<endl<<"Hand "<<j<<" contains the following cards"<<endl;
        for(int i=0;i<handSz;i++){
            Card card(hand[i]);
            cout<<setw(2)<<hand[i]<<" "<<card.face()<<card.suit()<<" "
                <<endl;
        }
        //Reallocate memory
        delete []hand;
    }
    
    //Display the results 
    
    //Reallocate memory
    
    //Exit stage right
    return 0;
}


