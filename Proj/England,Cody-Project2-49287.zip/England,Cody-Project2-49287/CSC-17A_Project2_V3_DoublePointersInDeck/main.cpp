/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on December 12, 2020, 8:38 PM
 * Purpose: Object Oriented Game of Mao
 * Version 3 - Create a deck of double pointers from Card class
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Card.h"
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here
    
    //Set constants
    const unsigned char DECKSZ = 52;
    //Declare Variables
    Card **deck;    //Card deck class
    
    //Initialize Variables (the deck)
    deck = new Card *[DECKSZ];      //Allocate memory for array of 52 card 
                                    //pointers
    for(int i=0;i<DECKSZ;i++){
        deck[i] = new Card(i);
    }
    //Process inputs to outputs/map
    for(int i = 0; i < DECKSZ; i++){
        cout <<i+1<< " " << deck[i]->face() << deck[i]->suit() << " " <<endl;
        
    }
    //Display the results

    //Reallocate Memory
    for(int i=0;i<DECKSZ;i++){
        delete deck[i];       //Destruction of each individual card
    }
    delete []deck;            //Destruction of the array of pointers

    
    //Exit stage right
    return 0;
}
