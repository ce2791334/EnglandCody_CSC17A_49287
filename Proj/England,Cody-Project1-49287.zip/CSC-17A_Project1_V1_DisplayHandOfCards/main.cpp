/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 4, 2020, 3:39 PM
 * Purpose: Game of Mao
 * Version: 1.0 - Display a random hand of cards
 */

//System libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
#include <cstdlib>   //Random Function Library
#include <ctime>     //Time Library to Set Seed
#include <cstring>   //String library
using namespace std;
//User Libraries - None
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare variables or constants here
    //7 characters or less
    int nmCds = 52;
    //Print cards
    //Display top edge of cards
    for (int i = 0; i < 12; i++)
      cout << " - - -";
    
    cout << endl;
    
    //Display card number
    for (int i = 0; i < 12; i++)
    {
        cout << "|" << setw(2);
  
        int rdcrd = rand() % nmCds;
        char suit;
        if(rdcrd <= 12)suit='S';
        else if(rdcrd <= 25)suit='C';
        else if(rdcrd <= 38)suit='D';
        else suit='H';
        char face;
        switch(rdcrd % 13+1){
            case 1:face='A';break;
            case 2:face='2';break;
            case 3:face='3';break;
            case 4:face='4';break;
            case 5:face='5';break;
            case 6:face='6';break;
            case 7:face='7';break;
            case 8:face='8';break;
            case 9:face='9';break;
            case 10:face='T';break;
            case 11:face='J';break;
            case 12:face='Q';break;
            case 13:face='K';break;
            default:cout<<"Bad Condition"<<endl;
        }
        if (face == 'T')
        cout << "10" << suit << setw(3);
        else cout << face << suit << setw(3);
    }
    cout << "|" << endl;
    
    //Display sides of cards
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 12; j++)
        cout << "|" << setw(6);  
        
        cout << "|" << endl;
    }
    
    //Display bottom edge of cards
    for (int i = 0; i < 12; i++)
      cout << " - - -";
    
    cout << endl;
    //Initialize or input data here
    
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    return 0;
}
