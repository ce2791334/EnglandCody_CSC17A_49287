/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 13, 2020, 8:30 AM
 * Purpose: Game of Mao
 * Version: 1.1 - Create hand as a dynamic arrays; move display 
 * to its own fxn
 */

//System libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
#include <cstdlib>   //Random Function Library
#include <ctime>     //Time Library to Set Seed
#include <cstring>   //String library
using namespace std;
//User Libraries - None
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
void prntcds(string *, int);     //Print hand

//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
//Declare variables or constants here
//7 characters or less
    int deck = 52,
        iP1HdSz = 12;    
    //Initialize or input data here
    
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    string *Hand = new string[iP1HdSz];           ////Create1
    //Loop to assign initial hand
    for (int i = 0; i < iP1HdSz; i++)
    {
        char suit; 
        string face;
        int rdcrd = rand() % deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            Hand[i] = face;
    }
    //Format and display outputs here
    prntcds(Hand, iP1HdSz);
    
    
    delete []Hand;                    ///////Delete1
 
    return 0;
}



void prntcds(string *hand, int hdSize)
{
    //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    
    //Display top edge of cards
    for (int i = 0; i < hdSize; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (int i = 0; i < hdSize; i++)
    {
        cout << "|" << setw(3);
       
        //ten.copy(1,1,hand[i]) != 'T'
        //if (1)
        cout << hand[i] << setw(3);
        //I want to show the number 10
        //else
           // cout << "10" << hand[i] << setw(3);
    }
    cout << "|" << endl;
    
    //Display sides of cards
    for (int i = 0; i < crdHt; i++){
        for (int j = 0; j < 12; j++)
        cout << "|" << setw(6);  
        cout << "|" << endl;
    }
    
    //Display bottom edge of cards
    for (int i = 0; i < hdSize; i++)
      cout << " - - -";
    
    cout << endl;
}
