/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 24, 2020, 12:00 PM
 * Purpose: Game of Mao
 * Version: 5 - Transfer card arrays to structures
 * (Also made some bug fixes)
 */

//System libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
#include <cstdlib>   //Random Function Library
#include <ctime>     //Time Library to Set Seed
#include <cstring>   //String library
using namespace std;
//User Libraries
#include "Cards.h"      
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
void prntCds(Cards *, const unsigned char);     //Print hand
Cards *dealP1(const unsigned char,const unsigned char); //Deal Player 
Cards *dealAI(Cards *,const unsigned char,const unsigned char);
void topCd(Cards *,Cards *,const unsigned char,const unsigned char);
void prtTpCd(string);
void destroy(Cards *, const unsigned char);          //Delete allocated memory

//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
//Declare variables or constants here
//7 characters or less
    const unsigned char DECK = 52;
    const unsigned char STHDSZ = 12;  
 
    //Initialize or input data here
    
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    Cards *P1 = dealP1(STHDSZ, DECK);           ////Create1
    Cards *AI = dealAI(P1, STHDSZ, DECK);           ////Create1
    
    //Start game
    //Get top card off deck
    topCd(P1, AI, DECK, STHDSZ);
    //Format and display outputs here
    prntCds(P1, STHDSZ);
    prntCds(AI, STHDSZ);
    
    destroy(P1, STHDSZ);
    destroy(AI, STHDSZ);
 
    //Exit Stage Right
    return 0;
}

//Begin function to deal P1 hand
Cards *dealP1(const unsigned char HdSz, const unsigned char Deck)
{
    //Allocate memory for a new Player 1 hand
    Cards *dealP1 = new Cards;
    dealP1->hand = new Hand[Deck];    //Largest number of cards
                                       //there could be
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
      bool dupChk = false; //Flag variable to check for duplicate
                           //cards
      do{
        char suit; 
        string face;
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
                dealP1->hand[i].card = face;
                //Check if card is a duplicate
                for(int chk = 0; chk < i; chk++)
                {
                    if(dealP1->hand[i].card == dealP1->hand[chk].card)
                    {
                        dupChk = true;
                        break;
                    }
                    else dupChk = false;
                }
      } while(dupChk);
    }
    
    return dealP1;
}

//Begin function to deal AI hand
Cards *dealAI(Cards *P1Hd, const unsigned char HdSz, 
              const unsigned char Deck)
{
    //Allocate memory for a new Player 1 hand
    Cards *dealAI = new Cards;
    dealAI->hand = new Hand[Deck];    //Largest number of cards
                                       //there could be
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
      bool dupChk = false; //Flag variable to check for duplicate
                           //cards
      do{
        char suit; 
        string face;
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            dealAI->hand[i].card = face;
            
            //Check if card is a duplicate
            for(int chk = 0; chk < i; chk++)
            {
                if(dealAI->hand[i].card == P1Hd->hand[chk].card || 
                  dealAI->hand[i].card == dealAI->hand[chk].card)
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }
      } while(dupChk);
    } 
    return dealAI;
}

//Begin function to display the hand
void prntCds(Cards *hand, const unsigned char hdSize)
{
    //Declare fxn variables
    unsigned char crdHt = 2;          //height of card
    
    //Display top edge of cards
    for (unsigned char i = 0; i < hdSize; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (unsigned char i = 0; i < hdSize; i++)
    {
        cout << "|" << setw(2);
       
        if (hand->hand[i].card[0] != 'T')
        cout << hand->hand[i].card << setw(4);
        //I want to show the number 10
        else
            cout << "10" << hand->hand[i].card[1] << setw(3);               /////////Ask in lab
    }
    cout << "|" << endl;
    
    //Display sides of cards
    for (int i = 0; i < crdHt; i++){
        for (int j = 0; j < 12; j++)
        cout << "|" << setw(6);  
        cout << "|" << endl;
    }
    
    //Display bottom edge of cards
    for (int i = 0; i < hdSize; i++)
      cout << " - - -";
    
    cout << endl;
}

//Begin fxn to find the top card of the deck       
//(will evolve in next version after deck is created)
void topCd(Cards *P1,Cards *AI, const unsigned char Deck,
           const unsigned char HdSz)
{
    //Declare variables
    char suit; 
    string face;
    bool dupChk = false; //Flag variable to check for duplicate
                           //cards
    //Get current hand size of each player
    /*while(P1Sz < HdSz)
        P1Sz++;
    while(AISz < HdSz)
        AISz++;*/
    //Create a unique random card off the top of deck
      do{
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            
            //Check if card is a duplicate
            for(int chk = 0; chk < HdSz; chk++)
            {
                if(face == P1->hand[chk].card || 
                   face == AI->hand[chk].card)
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }
      } while(dupChk); 
      //Print the top card
     prtTpCd(face);
}

//Begin fxn to print the top card of the deck
void prtTpCd(string card)
{
       //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    
    //Display "deck"
      cout << " X X X   - - - " << endl;
    for (int i = 0; i < crdHt + 1; i++){
        for(int j = 0; j < crdHt * 2; j++)
        cout << "X ";  
        cout << "|" << setw(2);
        if(i == 0)
            cout << card << setw(4) << "|" << endl;
        else{
            cout << setw(6) << "|" << endl;
        }
        
    }
      cout << " X X X   - - - " << endl;
}

//Begin fxn to delete allocated memory
void destroy(Cards *Hand, const unsigned char hdSz)
{
    delete []Hand->hand;                    ///////Delete1
    delete Hand;                    //////Delete2
}