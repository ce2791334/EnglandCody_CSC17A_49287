/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 25, 2020, 5:13 PM
 * Purpose: Game of Mao
 * Version: 10 - Adjust hands after a card is played, adjust deck
 * when top card is shown, create discard pile dynamic array
 */

//System libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
#include <cstdlib>   //Random Function Library
#include <ctime>     //Time Library to Set Seed
#include <cstring>   //String library
#include <fstream>   //File library
using namespace std;
//User Libraries
#include "Cards.h"      
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
//Create the deck
Cards *deck(const unsigned char);
Cards *dealP1(fstream &,Cards *,const unsigned char);     //Deal Player 1 hand 
Cards *dealAI(fstream &,Cards *,const unsigned char);     //Deal AI hand 
void prntCds(fstream &,Cards *,const unsigned char);        //Print hand
Cards *prtTpCd(Cards *,unsigned char);         //Start game by showing 
                                               //the top card off deck
void prntDck(Cards *); //Temp fxn to view deck contents
void destroy(Cards *,const unsigned char);     //Delete allocated memory
void wrtBin(fstream &,Cards *);                //Write the hands to files
void playCrd(fstream &,Cards *);               //Play a card
void AIplay(fstream &,Cards *);                //AI's turn to play
void swap(Cards *,unsigned char);              //Swap cards to adjust for plays

//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
//Declare variables or constants here
//7 characters or less
    const unsigned char DECK = 52;
    const unsigned char DEALSZ = 12; //This variable could be removed
                                     //but leaving it here allows for easy
                                     //adjustment of starting hand size if
                                     //desired
    fstream P1File;                  //File to hold Player 1's hand
    fstream AIFile;                  //File to hold AI player's hand
    //Start game
    
    //Initialize or input data here 
    //Create the deck
    Cards *Deck = deck(DECK);                 ////Create3
    prntDck(Deck);
    //Deal hands
    Cards *P1 = dealP1(P1File, Deck, DEALSZ);        ////Create1
    Cards *AI = dealAI(AIFile, Deck, DEALSZ);       ////Create2
    
    unsigned char posn = DECK - Deck->hand->hdSz;
    //Format and display outputs here
    //Print the top card
    Cards *discrd = prtTpCd(Deck, posn);
    //Print hands
    prntCds(P1File, P1, DEALSZ);
    prntCds(AIFile, AI, DEALSZ);
    
    //Begin gameplay
    playCrd(P1File, P1);
    AIplay(AIFile, AI);
    prntCds(P1File, P1, DEALSZ);
    prntCds(AIFile, AI, DEALSZ);
    //Close files
    P1File.close();
    AIFile.close();
    //Delete allocated memory
    destroy(P1, DEALSZ);
    destroy(AI, DEALSZ);
    destroy(Deck,DECK); 
    destroy(discrd, discrd->hand->hdSz);
    //Exit Stage Right
    return 0;
}

//Begin fxn to create the rest of the deck
Cards *deck(const unsigned char Deck)
{
    //Declare variables
    char suit; 
    string face;
    bool dupChk = false; //Flag variable to check for duplicate
                         //cards
    //Allocate memory for the deck after dealing the hands
    Cards *deck = new Cards;
    deck->hand = new Hand[Deck];    //Largest number of cards
                                       //there could be
    //Initialize size of deck
    deck->hand->hdSz = Deck;
    //Loop to assign initial hand
    for (int i = 0; i < Deck; i++)
    {
    //Create a unique random card off the top of deck
    //I chose this method of randomly assigning the cards in the deck 
    //removes the need to shuffle, but may cause program to take longer
    //to run as the loop goes until all cards are unique
      do{
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            deck->hand[i].card = face;
            //Check if card is a duplicate of one already in deck
            for(int chkDk = 0; chkDk < i; chkDk++)
            {
                if(deck->hand[i].card  == deck->hand[chkDk].card)
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }
      } while(dupChk); 
    }
    return deck;
}

//Begin function to deal P1 hand
Cards *dealP1(fstream &P1File, Cards *deck, const unsigned char HdSz)
{
    //Allocate memory for a new Player 1 hand
    Cards *dealP1 = new Cards;
    dealP1->hand = new Hand[deck->hand->hdSz];    //Largest number of cards
                                                  //there could be
    //Initialize starting hand size
    dealP1->hand->hdSz = HdSz;
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
        //Multiply position in deck by 2 to simulate even 
        //dealing between players
        dealP1->hand[i].card = deck->hand[i*2].card;
    }
     //Write hand contents to a binary file
     wrtBin(P1File, dealP1);
    //Adjust size of deck to account for dealt cards
    deck->hand->hdSz = deck->hand->hdSz - HdSz;
    return dealP1;
}

//Begin function to deal AI hand
Cards *dealAI(fstream &AIFile, Cards *deck, const unsigned char HdSz)
{
    //Allocate memory for a new Player 1 hand
    Cards *dealAI = new Cards;
    dealAI->hand = new Hand[deck->hand->hdSz];    //Largest number of cards
                                                  //there could be
    //Initialize starting hand size
    dealAI->hand->hdSz = HdSz;
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
        //Multiply position in deck by 2 to simulate even 
        //dealing between players
        dealAI->hand[i].card = deck->hand[i*2 + 1].card;
    }
    //Write hand contents to a binary file
    wrtBin(AIFile, dealAI);
    //Adjust size of deck to account for dealt cards
    deck->hand->hdSz = deck->hand->hdSz - HdSz;
    return dealAI;
}

//Begin fxn to write the starting hands to files
void wrtBin(fstream &binFile, Cards *hnd)
{
    hnd->hand[hnd->hand->hdSz + 1].card = hnd->hand[0].card;
    //Open file
    binFile.open("P1.bin",ios::out|ios::binary);
    //Write card to file
    for(unsigned char i = 0 ; i < hnd->hand->hdSz; i++)
    {
    binFile.seekp(i, ios::beg);
    binFile.write(reinterpret_cast<char *>(&hnd->hand[i].card[0]),
            sizeof(char));
    binFile.write(reinterpret_cast<char *>(&hnd->hand[i].card[1]),
            sizeof(char));
    }
    //close file
    binFile.close();
}

//Begin function to display the hand
void prntCds(fstream &inBin, Cards *hand, const unsigned char hdSize)
{
    //Declare fxn variables
    unsigned char crdHt = 2;          //height of card
    //Open file to get hand from
    inBin.open("P1.bin",ios::in|ios::binary);                
    for(unsigned char i = 0 ; i < hand->hand->hdSz; i++)
    {
    inBin.read(reinterpret_cast<char *>(&hand->hand->card[0]), sizeof(char));
    inBin.read(reinterpret_cast<char *>(&hand->hand->card[1]),sizeof(char));
    }
    //Reset first card to proper value
    hand->hand[0].card = hand->hand[hand->hand->hdSz + 1].card;
    //Display top edge of cards
    for (unsigned char i = 0; i < hand->hand->hdSz; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (unsigned char i = 0; i < hand->hand->hdSz; i++)
    {
        cout << "|" << setw(2);
        //I want to show the number 10
        if (hand->hand[i].card[0] != 'T')
        cout << hand->hand[i].card << setw(4);
        else
            cout << "10" << hand->hand[i].card[1] << setw(3);
    }
      //Close file
      inBin.close();
    cout << "|" << endl;
    //Display sides of cards
    for (int i = 0; i < crdHt; i++)
    {
        for (int j = 0; j < hand->hand->hdSz; j++)
        cout << "|" << setw(6);  
        cout << "|" << endl;
    }
    //Display bottom edge of cards
    for (int i = 0; i < hand->hand->hdSz; i++)
      cout << " - - -";
    
    cout << endl;
}

//Begin fxn to print the top card of the deck
Cards *prtTpCd(Cards *deck, unsigned char pos)
{
    //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    //Allocate memory for a discard pile
    Cards *discrd = new Cards;
    discrd->hand = new Hand[deck->hand->hdSz];    //Largest number of cards
                                                  //there could be
    //First card in discard pile will be the top card off the deck
    discrd->hand[0].card = deck->hand[pos].card;
    //Initialize size of discard pile to 1
    discrd->hand->hdSz = 1;
    //Display "deck"
      cout << " X X X   - - - " << endl; //Top edge
    //Loop to display centers of top of next card in deck
    //and the face of the card shown
    for (int i = 0; i < crdHt + 1; i++)
    {
        for(int j = 0; j < crdHt * 2; j++)
        cout << "X ";  
        cout << "|" << setw(2);
        if(i == 0)
            cout << deck->hand[pos].card << setw(4) << "|" << endl;
        else{
            cout << setw(6) << "|" << endl;
        }
    }
      cout << " X X X   - - - " << endl;
      //Account for displayed card in remaining deck size
      deck->hand->hdSz--;
      
      return discrd;
}

//Begin fxn to delete allocated memory
void destroy(Cards *Hand, const unsigned char hdSz)
{
    delete []Hand->hand;            ///////Delete1
    delete Hand;                    //////Delete2
}

//Begin fxn to play a card
void playCrd(fstream &file, Cards *hand)
{
    //Declare fxn variables
    string play;    //Will hold input value of card user plays
    bool valid = true;  //Boolean value to check that card played is valid
    unsigned char posn; //Will hold the position of the card played
    //Enter do while loop to ask player for a card as long as they enter an
    //invalid card
    do{
        //Ask player to enter the card they want to play
        cout << endl << "Enter the face value and suit of the card "
             << "you want to play (enter 'T' for 10):" << endl;
        cin >> play;
     
        //Loop to check that card played is one from hand
        for(unsigned char i = 0; i < hand->hand->hdSz; i++)
        {
           //If card isn't in the player's hand
           if(hand->hand[i].card != play) 
               valid = false;
           else
           {
               posn = i;
               valid = true;
               break;
           }
        }
        if(!valid)
        {
            cout << "The card you're trying to play isn't in your hand!"
                 << endl;
        }
    }while(!valid);
    //remove the card played from player's hand
    hand->hand[posn].card = '0';
    swap(hand, posn);
    //Decrement hand size
    hand->hand->hdSz--;
    //Write the new hand to file
    wrtBin(file, hand);   
}

//Begin fxn to display the card played by the AI
void AIplay(fstream &file, Cards *AI)
{
    //Play a random card from the AI's hand 
    //Will be adjusted later when game rules are added
    int indx = rand() % AI->hand->hdSz;
    cout << AI->hand[indx].card << endl;
    //remove the card played from player's hand
    AI->hand[indx].card = '0';
    swap(AI, indx);
    //Decrement hand size
    AI->hand->hdSz--;
    //Write the new hand to file
    wrtBin(file, AI); 
    
}

//Begin temporary fxn to display the deck contents 
void prntDck(Cards *deck)
{
    for(int i = 0; i < deck->hand->hdSz; i++){
        if (i % 3 == 0 && i != 0)
        cout << endl;
        cout << deck->hand[i].card << "   ";
    }cout << endl;
}

//Begin swap fxn to adjust hand for card plays
void swap(Cards *hand, unsigned char posn)
{
    for(unsigned char i = posn; i < hand->hand->hdSz; i++)
    {
        string temp = hand->hand[i].card;
        hand->hand[i].card = hand->hand[i + 1].card;
        hand->hand[i + 1].card = temp;
    }
}