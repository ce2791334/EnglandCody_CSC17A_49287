/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 13, 2020, 7:17 PM
 * Purpose: Game of Mao
 * Version: 4 - create fxn to display card off top of 
 * deck
 */

//System libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
#include <cstdlib>   //Random Function Library
#include <ctime>     //Time Library to Set Seed
#include <cstring>   //String library
using namespace std;
//User Libraries - None
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
void prntCds(string *, int);     //Print hand
string *dealP1(int,const int);
string *dealAI(string *,int,const int);
void topCd(string *,string *,const int,int,int);
void prtTpCd(string);

//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
//Declare variables or constants here
//7 characters or less
    const int DECK = 52;
    int HdSz = 12;  
 
    //Initialize or input data here
    
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    string *P1Hand = dealP1(HdSz, DECK);           ////Create1
    string *AIHand = dealAI(P1Hand, HdSz, DECK);           ////Create1
    
    //Start game
    //Get top card off deck
    topCd(P1Hand, AIHand, DECK, HdSz, HdSz);
    //Format and display outputs here
    prntCds(P1Hand, HdSz);
    prntCds(AIHand, HdSz);
    
    delete []P1Hand;                    ///////Delete1
    delete []AIHand;                    //////Delete2
 
    return 0;
}

//Begin function to deal P1 hand
string *dealP1(int HdSz, const int Deck)
{
    string *iHnd = new string[HdSz];
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
      bool dupChk = false; //Flag variable to check for duplicate
                           //cards
      do{
        char suit; 
        string face;
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            iHnd[i] = face;
            
            //Check if card is a duplicate
            for(int chk = 0; chk < i; chk++)
            {
                if(iHnd[chk] == iHnd[i])
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }
      } while(dupChk);
    }
    
    return iHnd;
}

//Begin function to deal P1 hand
string *dealAI(string *P1Hd, int HdSz, const int Deck)
{
    string *iHnd = new string[HdSz];
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
      bool dupChk = false; //Flag variable to check for duplicate
                           //cards
      do{
        char suit; 
        string face;
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            iHnd[i] = face;
            
            //Check if card is a duplicate
            for(int chk = 0; chk < HdSz; chk++)
            {
                if(iHnd[i] == P1Hd[chk])
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }   
            
            //dupChk = false;
      } while(dupChk);
      //cout << dupChk << endl;
    } 
    
    return iHnd;
}

//Begin function to display the hand
void prntCds(string *hand, int hdSize)
{
    //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    
    //Display top edge of cards
    for (int i = 0; i < hdSize; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (int i = 0; i < hdSize; i++)
    {
        cout << "|" << setw(3);
       
        //ten.copy(1,1,hand[i]) != 'T'
        //if (1)
        cout << hand[i] << setw(3);
        //I want to show the number 10
        //else
           // cout << "10" << hand[i] << setw(3);               /////////Ask in lab
    }
    cout << "|" << endl;
    
    //Display sides of cards
    for (int i = 0; i < crdHt; i++){
        for (int j = 0; j < 12; j++)
        cout << "|" << setw(6);  
        cout << "|" << endl;
    }
    
    //Display bottom edge of cards
    for (int i = 0; i < hdSize; i++)
      cout << " - - -";
    
    cout << endl;
}


void topCd(string *P1,string *AI, const int Deck, int P1HdSz, int AIHdSz)
{
    //Declare variables
    char suit; 
    string face;
    bool dupChk = false; //Flag variable to check for duplicate
                           //cards
    int P1Sz = 0, 
        AISz = 0;
    //Get current hand size of each player
    while(P1Sz < P1HdSz)
        P1Sz++;
    while(AISz < AIHdSz)
        AISz++;
    //Create a unique random card off the top of deck
      do{
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            
            //Check if card is a duplicate
            for(int chk = 0; chk < P1Sz; chk++)
            {
                if(face == P1[chk])
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }
            
            if(!dupChk)
            for(int chk = 0; chk < AISz; chk++)
            {
                if(face == AI[chk])
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }

      } while(dupChk); 
    
     prtTpCd(face);
}


void prtTpCd(string card)
{
       //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    
    //Display "deck"
      cout << " X X X   - - - " << endl;
    for (int i = 0; i < crdHt + 1; i++){
        for(int j = 0; j < crdHt * 2; j++)
        cout << "X ";  
        cout << "|" << setw(3);
        if(i == 0)
            cout << card << setw(3) << "|" << endl;
        else{
            cout << setw(6) << "|" << endl;
        }
        
    }
      cout << " X X X   - - - " << endl;
}