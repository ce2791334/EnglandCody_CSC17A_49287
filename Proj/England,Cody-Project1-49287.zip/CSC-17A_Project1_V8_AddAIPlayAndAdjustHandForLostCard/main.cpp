/* 
 * File:   main.cpp
 * Author: Cody England
 * Created on October 24, 2020, 6:07 PM
 * Purpose: Game of Mao
 * Version: 8 - Add in an AI play
 */

//System libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
#include <cstdlib>   //Random Function Library
#include <ctime>     //Time Library to Set Seed
#include <cstring>   //String library
using namespace std;
//User Libraries
#include "Cards.h"      
//Global Constants
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.
// - None

//Function Prototypes
//Create the deck
Cards *deck(const unsigned char);
Cards *dealP1(Cards *,const unsigned char);     //Deal Player 1 hand 
Cards *dealAI(Cards *,const unsigned char);     //Deal AI hand 
void prntCds(Cards *, const unsigned char);     //Print hand
void prtTpCd(string);                           //Start game by showing 
                                                //the top card off deck
void prntDck(Cards *); //Temp fxn to view deck contents
void destroy(Cards *, const unsigned char);     //Delete allocated memory
void playCrd(Cards *);                          //Play a card
void AIplay(Cards *);                           //AI's turn to play

//Execution Begins Here
int main(int argc, char** argv) {
//Set random number seed here when needed
    srand(static_cast<unsigned int>(time(0)));
//Declare variables or constants here
//7 characters or less
    const unsigned char DECK = 52;
    const unsigned char DEALSZ = 12; //This variable could be removed
                                     //but leaving it here allows for easy
                                     //adjustment of starting hand size if
                                     //desired
    //Start game
    
    //Initialize or input data here 
    //Create the deck
    Cards *Deck = deck(DECK);
    //Deal hands
    Cards *P1 = dealP1(Deck, DEALSZ);           ////Create1
    Cards *AI = dealAI(Deck, DEALSZ);       ////Create1
        
    //Format and display outputs here
    //Print the top card
    prtTpCd(Deck->hand[0].card);
    //Print hands
    prntCds(P1, DEALSZ);
    prntCds(AI, DEALSZ);
    //prntDck(Deck);
    
    //Begin gameplay
    playCrd(P1);
    AIplay(AI);
    //Delete Allocated memory
    destroy(P1, DEALSZ);
    destroy(AI, DEALSZ);
    destroy(Deck,DECK); 
    //Exit Stage Right
    return 0;
}

//Begin fxn to create the rest of the deck
Cards *deck(const unsigned char Deck)
{
    //Declare variables
    char suit; 
    string face;
    bool dupChk = false; //Flag variable to check for duplicate
                         //cards
    //Allocate memory for the deck after dealing the hands
    Cards *deck = new Cards;
    deck->hand = new Hand[Deck];    //Largest number of cards
                                       //there could be
    //Initialize size of deck
    deck->hand->hdSz = Deck;
    //Loop to assign initial hand
    for (int i = 0; i < Deck; i++)
    {
    //Create a unique random card off the top of deck
    //I chose this method of randomly assigning the cards in the deck 
    //removes the need to shuffle, but may cause program to take longer
    //to run as the loop goes until all cards are unique
      do{
        int rdcrd = rand() % Deck;
        if(rdcrd <= 12)suit = 'S';
        else if(rdcrd <= 25)suit = 'C';
        else if(rdcrd <= 38)suit = 'D';
        else suit = 'H';
        switch(rdcrd % 13+1){
            case 1:face = "A";break;
            case 2:face = "2";break;
            case 3:face = "3";break;
            case 4:face = "4";break;
            case 5:face = "5";break;
            case 6:face = "6";break;
            case 7:face = "7";break;
            case 8:face = "8";break;
            case 9:face = "9";break;
            case 10:face = "T";break;
            case 11:face = "J";break;
            case 12:face = "Q";break;
            case 13:face = "K";break;
            default:cout<<"Bad Condition"<<endl;
        }   
            face.append(1, suit);
            deck->hand[i].card = face;
            //Check if card is a duplicate of one already in deck
            for(int chkDk = 0; chkDk < i; chkDk++)
            {
                if(deck->hand[i].card  == deck->hand[chkDk].card)
                {
                    dupChk = true;
                    break;
                }
                else dupChk = false;
            }
      } while(dupChk); 
    }
    return deck;
}

//Begin function to deal P1 hand
Cards *dealP1(Cards *deck, const unsigned char HdSz)
{
    //Allocate memory for a new Player 1 hand
    Cards *dealP1 = new Cards;
    dealP1->hand = new Hand[deck->hand->hdSz];    //Largest number of cards
                                                  //there could be
    //Initialize starting hand size
    dealP1->hand->hdSz = HdSz;
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
        //Multiply position in deck by 2 to simulate even 
        //dealing between players
        dealP1->hand[i].card = deck->hand[i*2].card;
    }
    return dealP1;
}

//Begin function to deal AI hand
Cards *dealAI(Cards *deck, const unsigned char HdSz)
{
    //Allocate memory for a new Player 1 hand
    Cards *dealAI = new Cards;
    dealAI->hand = new Hand[deck->hand->hdSz];    //Largest number of cards
                                                  //there could be
    //Initialize starting hand size
    dealAI->hand->hdSz = HdSz;
    //Loop to assign initial hand
    for (int i = 0; i < HdSz; i++)
    {
        //Multiply position in deck by 2 to simulate even 
        //dealing between players
        dealAI->hand[i].card = deck->hand[i*2 + 1].card;
    }
    return dealAI;
}

//Begin function to display the hand
void prntCds(Cards *hand, const unsigned char hdSize)
{
    //Declare fxn variables
    unsigned char crdHt = 2;          //height of card
    //Display top edge of cards
    for (unsigned char i = 0; i < hdSize; i++)
      cout << " - - -";
      cout << endl;
    //Display card number/suit
    for (unsigned char i = 0; i < hdSize; i++)
    {
        cout << "|" << setw(2);
       //I want to show the number 10
        if (hand->hand[i].card[0] != 'T')
        cout << hand->hand[i].card << setw(4);
        else
            cout << "10" << hand->hand[i].card[1] << setw(3); 
    }
    cout << "|" << endl;
    //Display sides of cards
    for (int i = 0; i < crdHt; i++){
        for (int j = 0; j < 12; j++)
        cout << "|" << setw(6);  
        cout << "|" << endl;
    }
    //Display bottom edge of cards
    for (int i = 0; i < hdSize; i++)
      cout << " - - -";
    
    cout << endl;
}

//Begin fxn to print the top card of the deck
void prtTpCd(string card)
{
    //Declare fxn variables
    char crdHt = 2;          //height of card
    string ten;       //To test for card value of 1
    //Display "deck"
      cout << " X X X   - - - " << endl; //Top edge
    //Loop to display centers of top of next card in deck
    //and the face of the card shown
    for (int i = 0; i < crdHt + 1; i++)
    {
        for(int j = 0; j < crdHt * 2; j++)
        cout << "X ";  
        cout << "|" << setw(2);
        if(i == 0)
            cout << card << setw(4) << "|" << endl;
        else{
            cout << setw(6) << "|" << endl;
        }
    }
      cout << " X X X   - - - " << endl;
}

//Begin fxn to delete allocated memory
void destroy(Cards *Hand, const unsigned char hdSz)
{
    delete []Hand->hand;            ///////Delete1
    delete Hand;                    //////Delete2
}

//Begin fxn to play a card
void playCrd(Cards *hand)
{
    //Declare fxn variables
    string play;    //Will hold input value of card user plays
    bool valid = true;  //Boolean value to check that card played is valid
    //Enter do while loop to ask player for a card as long as they enter an
    //invalid card
    do{
        //Ask player to enter the card they want to play
        cout << endl << "Enter the face value and suit of the card "
             << "you want to play (enter 'T' for 10):" << endl;
        cin >> play;
     
        //Loop to check that card played is one from hand
        for(unsigned char i = 0; i < hand->hand->hdSz; i++)
        {
           //If card isn't in the player's hand
           if(hand->hand[i].card != play)               
               valid = false;
           else
           {
               valid = true;
               break;
           }
        }
        if(!valid)
        {
            cout << "The card you're trying to play isn't in your hand!"
                 << endl;
        }
    }while(!valid);
    
        cout << play << endl;    
}

//Begin fxn to display the card played by the AI
void AIplay(Cards *AI)
{
    //Play a random card from the AI's hand 
    //Will be adjusted later when game rules are added
    int indx = rand() % AI->hand->hdSz;
    cout << AI->hand[indx].card << endl;
}

//Begin temporary fxn to display the deck contents 
void prntDck(Cards *deck)
{
    for(int i = 0; i < deck->hand->hdSz; i++){
        if (i % 3 == 0 && i != 0)
        cout << endl;
        cout << deck->hand[i].card << "   ";
    }
}
